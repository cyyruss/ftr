# Fairy Tail: Rewired Integration API — v1

Available after the `ready` hook as `game.fairyTailRewired`.

## Top-level API

- `version`, `apiVersion`, `schemaVersion`, `config`
- `useItem(uuid, options)` — run the system Item workflow.
- `roll.d20`, `roll.ability`, `roll.save`, `roll.skill`, `roll.damage`
- `conditions.apply`, `conditions.clear`, `conditions.recover`
- `combat.applyTargetedDamage`, `combat.mitigationFor`, `combat.slayerMultiplier`
- `summoning.summon`, `summoning.dismiss`, `summoning.dismissAll`
- `apps.openCharacterBuilder(actor)`, `apps.openPartyTracker()`, `apps.openMagicProgression(actor)`
- `progression.pending`, `progression.status`, `progression.choose`, `progression.remove`
- `content.registerProvider`, `content.unregisterProvider`, `content.listProviders`, `content.getActors`, `content.getItems`, `content.importActor`, `content.importItem`, `content.open`
- `migrate()`
- `Workflow` — workflow class for integrations.

## Item workflow hooks

Cancellable synchronous hooks return `false`:

- `ftr.preUseItem`
- `ftr.workflow.preValidate`
- `ftr.workflow.preCost`
- `ftr.workflow.preRoll`
- `ftr.workflow.preMessage`
- `ftr.workflow.preApply`

Notification hooks:

- `ftr.workflow.postValidate`
- `ftr.workflow.postCost`
- `ftr.workflow.postRoll`
- `ftr.workflow.postMessage`
- `ftr.workflow.postApply`
- `ftr.workflow.complete`
- `ftr.useItem`

Foundry hooks are synchronous and are not awaited. Integrations that need to cancel a pre-stage must return `false` synchronously.

## Other hooks

- `ftr.init`, `ftr.ready`
- `ftr.resourceSpent`, `ftr.resourceRecovered`
- `ftr.damageApplied`, `ftr.healingApplied`
- `ftr.conditionChanged`
- `ftr.turnStart`, `ftr.turnEnd`
- `ftr.summoned`, `ftr.dismissed`
- `ftr.shortRest`, `ftr.longRest`
- `ftr.advancementRecorded`
- `ftr.builderApplied`
- `ftr.magicPathChosen`, `ftr.magicPathRemoved`
- `ftr.contentProviderRegistered`, `ftr.contentProviderUnregistered`, `ftr.contentImported`

## Content provider example

```js
game.fairyTailRewired.content.registerProvider("my-content", {
  label: "My Rewired Content",
  version: "1.0.0",
  getActors: async () => myActorSourceObjects,
  getItems: async () => myItemSourceObjects,
  openBrowser: () => myBrowser.render({force: true})
});
```

Use plain Foundry Actor/Item source objects conforming to this system's document types. The import helpers deep-clone source data and mark imported documents with system flags.
