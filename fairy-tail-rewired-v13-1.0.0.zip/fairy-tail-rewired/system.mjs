import {SYSTEM_ID, SYSTEM_VERSION, API_VERSION, SCHEMA_VERSION, FTR} from "./module/config.mjs";
import {CharacterData, NPCData, SummonData, FTRItemData} from "./module/data-models.mjs";
import {FTRActor} from "./module/documents/actor.mjs";
import {FTRItem} from "./module/documents/item.mjs";
import {FTRActorSheet, FTRNPCSheet} from "./module/sheets/actor-sheet.mjs";
import {FTRItemSheet} from "./module/sheets/item-sheet.mjs";
import {installStatusEffects, setRankedCondition, clearCondition, attemptConditionRecovery} from "./module/automation/conditions.mjs";
import {registerCombatHooks, applyTargetedDamage, mitigationFor, slayerMultiplier} from "./module/automation/combat.mjs";
import {summonFromItem, dismissSummon, dismissAllForCaster} from "./module/automation/summoning.mjs";
import {d20Roll, abilityRoll, saveRoll, skillRoll, damageRoll} from "./module/automation/rolls.mjs";
import {migrateWorld} from "./module/migrations.mjs";
import {openCharacterBuilder} from "./module/apps/character-builder.mjs";
import {openPartyTracker, registerPartyTrackerHooks} from "./module/apps/party-tracker.mjs";
import {openMagicProgression} from "./module/apps/progression-app.mjs";
import {pendingMagicChoices, progressionStatus, applyMagicChoice, removeMagicChoice} from "./module/progression/progression.mjs";
import {FTRWorkflow} from "./module/automation/workflow.mjs";
import {registerContentProvider, unregisterContentProvider, listContentProviders, providerActors, providerItems, importActorData, importItemData, openContentProvider} from "./module/integration/content-registry.mjs";

function registerSettings() {
  game.settings.register(SYSTEM_ID,"schemaVersion",{name:"Schema Version",scope:"world",config:false,type:Number,default:0});
  game.settings.register(SYSTEM_ID,"autoApplyDamage",{name:"Automatically Apply Damage",hint:"When enabled, item use applies rolled damage to currently targeted tokens immediately. Leave off for maximum module compatibility.",scope:"world",config:true,type:Boolean,default:false});
  game.settings.register(SYSTEM_ID,"automateTurnConditions",{name:"Automate Turn Conditions",hint:"Applies Burned and Winded turn damage and expires Slowed through combat hooks.",scope:"world",config:true,type:Boolean,default:true});
  game.settings.register(SYSTEM_ID,"loreExpansion",{name:"Enable Lore Expansion Content",hint:"Controls whether lore-expansion features are considered enabled by system automation. Compendium visibility is unaffected.",scope:"world",config:true,type:Boolean,default:true});
  game.settings.register(SYSTEM_ID,"sheetTheme",{name:"Character Sheet Theme",scope:"client",config:true,type:String,choices:{guild:"Guild Parchment",celestial:"Celestial",slayer:"Slayer",dark:"Dark Guild"},default:"guild"});
}

function registerHandlebars() {
  Handlebars.registerHelper("eq",(a,b)=>a===b || String(a)===String(b));
  Handlebars.registerHelper("signed",n=>Number(n)>=0?`+${Number(n)}`:`${Number(n)}`);
}

function registerDataModels() {
  CONFIG.Actor.dataModels.character=CharacterData;
  CONFIG.Actor.dataModels.npc=NPCData;
  CONFIG.Actor.dataModels.summon=SummonData;
  for (const t of ["spell","technique","weapon","armor","equipment","consumable","feature","feat","class","magic","race","background","celestialKey","transformation"]) CONFIG.Item.dataModels[t]=FTRItemData;
  CONFIG.Actor.documentClass=FTRActor;
  CONFIG.Item.documentClass=FTRItem;
}

function registerSheets() {
  Actors.unregisterSheet("core",foundry.appv1.sheets.ActorSheet);
  Actors.registerSheet(SYSTEM_ID,FTRActorSheet,{types:["character"],makeDefault:true,label:"Fairy Tail Rewired Character"});
  Actors.registerSheet(SYSTEM_ID,FTRNPCSheet,{types:["npc","summon"],makeDefault:true,label:"Fairy Tail Rewired NPC / Summon"});
  Items.unregisterSheet("core",foundry.appv1.sheets.ItemSheet);
  Items.registerSheet(SYSTEM_ID,FTRItemSheet,{makeDefault:true,label:"Fairy Tail Rewired Item"});
}

function registerChatActions() {
  Hooks.on("renderChatMessageHTML",(message,html)=>{
    if (!message.getFlag(SYSTEM_ID,"actorUuid")) return;
    html.querySelectorAll?.("[data-ftr-chat-action]").forEach(button=>button.addEventListener("click",()=>onChatAction(message,button.dataset.ftrChatAction)));
  });
}

async function actorsFromMessage(message) {
  const uuids=message.getFlag(SYSTEM_ID,"targets") ?? [];
  const out=[];
  for (const uuid of uuids) { try { const a=await fromUuid(uuid); if (a) out.push(a.actor ?? a); } catch (_) {} }
  return out;
}

async function onChatAction(message,action) {
  const actor=await fromUuid(message.getFlag(SYSTEM_ID,"actorUuid")).catch(()=>null);
  const item=await fromUuid(message.getFlag(SYSTEM_ID,"itemUuid")).catch(()=>null);
  const targets=await actorsFromMessage(message);
  if (!targets.length) return ui.notifications.warn("No valid targets were stored for this action.");
  const permitted=targets.filter(t=>game.user.isGM || t.isOwner);
  if (!permitted.length) return ui.notifications.warn("You do not own any of the stored targets.");
  const damage=message.getFlag(SYSTEM_ID,"damage") ?? [];
  if (action === "apply-damage") {
    for (const part of damage) await applyTargetedDamage({source:actor,targets:permitted,amount:Number(part.total||0),type:part.type,item});
    const condition=message.getFlag(SYSTEM_ID,"condition") ?? {};
    if (condition.key && Number(condition.rank||0)>0 && ["hit","always"].includes(condition.on)) {
      for (const target of permitted) await target.setRankedCondition(condition.key,Number(condition.rank),{additive:true,sourceUuid:item?.uuid||""});
    }
    return ui.notifications.info("Damage applied to stored targets.");
  }
  if (action === "apply-healing") {
    const total=damage.reduce((n,p)=>n+Number(p.total||0),0);
    for (const target of permitted) await target.heal(total,{source:item?.name??"Healing"});
    return ui.notifications.info("Healing applied to stored targets.");
  }
  if (action === "resolve-save") {
    const save=message.getFlag(SYSTEM_ID,"save") ?? {};
    const condition=message.getFlag(SYSTEM_ID,"condition") ?? {};
    const results=[];
    for (const target of permitted) {
      const roll=await target.rollSave(save.ability||"dex",{dc:Number(save.dc||10),label:`${item?.name??"Technique"} Save`});
      const success=Number(roll?.total||0)>=Number(save.dc||10);
      let applied=0;
      for (const part of damage) {
        let amount=Number(part.total||0);
        if (success && save.onSuccess === "half") amount=Math.floor(amount/2);
        if (success && save.onSuccess === "none") amount=0;
        if (amount) applied += await target.applyDamage(Math.floor(amount*slayerMultiplier(actor,target)),part.type,{source:item?.name??"Technique"});
      }
      const applyCondition=condition.key && Number(condition.rank||0)>0 && ((condition.on||"failedSave") === "always" || ((condition.on||"failedSave") === "failedSave" && !success));
      if (applyCondition) await target.setRankedCondition(condition.key,Number(condition.rank),{additive:true,dc:Number(save.dc||10),sourceUuid:item?.uuid||""});
      results.push(`${target.name}: ${success?"success":"failure"}${damage.length?` (${applied} damage)`:""}`);
    }
    await ChatMessage.create({speaker:ChatMessage.getSpeaker({actor}),content:`<div class="ftr-chat-card"><p><strong>${foundry.utils.escapeHTML(item?.name??"Technique")} — Save Results</strong></p><p>${results.map(foundry.utils.escapeHTML).join("<br>")}</p></div>`});
  }
}

function registerMacroSupport() {
  Hooks.on("hotbarDrop",async (bar,data,slot)=>{
    if (data.type !== "Item" || !data.uuid) return;
    const item=await fromUuid(data.uuid);
    if (!item || !(item instanceof Item)) return;
    const command=`game.fairyTailRewired.useItem("${item.uuid}")`;
    let macro=game.macros.find(m=>m.name===item.name && m.command===command);
    if (!macro) macro=await Macro.create({name:item.name,type:"script",img:item.img,command});
    await game.user.assignHotbarMacro(macro,slot);
    return false;
  });
}

function registerEffectCleanup() {
  Hooks.on("deleteActiveEffect",async effect=>{
    const resistance=effect.getFlag?.(SYSTEM_ID,"addedResistance");
    const actor=effect.parent;
    if (!resistance || !actor?.system?.defenses) return;
    const value=typeof resistance === "string" ? resistance : resistance.value;
    const wasNew=typeof resistance === "string" ? true : Boolean(resistance.wasNew);
    if (!value || !wasNew) return;
    const stillGranted=actor.effects.some(e=>e.id!==effect.id && (e.getFlag?.(SYSTEM_ID,"addedResistance")?.value ?? e.getFlag?.(SYSTEM_ID,"addedResistance"))===value);
    if (stillGranted) return;
    const arr=(actor.system.defenses.resistances??[]).filter(x=>x!==value);
    await actor.update({"system.defenses.resistances":arr});
  });
}

async function useItemByUuid(uuid,options={}) {
  const item=await fromUuid(uuid);
  if (!item?.use) return ui.notifications.warn("That UUID is not a usable Fairy Tail: Rewired item.");
  return item.use(options);
}

Hooks.once("init",()=>{
  console.log(`${SYSTEM_ID} | Initializing ${SYSTEM_VERSION}`);
  registerDataModels(); registerSettings(); registerHandlebars(); installStatusEffects(); registerSheets(); registerChatActions(); registerCombatHooks(); registerMacroSupport(); registerEffectCleanup(); registerPartyTrackerHooks();
  Hooks.callAll("ftr.init",{version:SYSTEM_VERSION,apiVersion:API_VERSION});
});

Hooks.once("ready",async()=>{
  const api={
    version:SYSTEM_VERSION, apiVersion:API_VERSION, schemaVersion:SCHEMA_VERSION, config:FTR,
    roll:{d20:d20Roll,ability:abilityRoll,save:saveRoll,skill:skillRoll,damage:damageRoll},
    conditions:{apply:setRankedCondition,clear:clearCondition,recover:attemptConditionRecovery},
    combat:{applyTargetedDamage,mitigationFor,slayerMultiplier},
    summoning:{summon:summonFromItem,dismiss:dismissSummon,dismissAll:dismissAllForCaster},
    apps:{openCharacterBuilder,openPartyTracker,openMagicProgression},
    progression:{pending:pendingMagicChoices,status:progressionStatus,choose:applyMagicChoice,remove:removeMagicChoice},
    Workflow:FTRWorkflow,
    content:{registerProvider:registerContentProvider,unregisterProvider:unregisterContentProvider,listProviders:listContentProviders,getActors:providerActors,getItems:providerItems,importActor:importActorData,importItem:importItemData,open:openContentProvider},
    migrate:migrateWorld,
    useItem:useItemByUuid
  };
  game.fairyTailRewired=api;
  await migrateWorld();
  Hooks.callAll("ftr.ready",api);
});
