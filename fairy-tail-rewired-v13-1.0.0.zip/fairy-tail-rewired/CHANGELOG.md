# Changelog

## 1.0.0

- Rebuilt the working v13 prototype around custom Actor/Item document classes and System Data Models.
- Removed the prototype-level global Actor monkey patch.
- Added custom Fairy Tail-inspired actor and item sheets plus original class emblems.
- Added Character Builder, Party Tracker, advancement history, and structured magic-path UI.
- Rebuilt the spell compendium from PDF layout coordinates: 115 source-derived entries with structured MP cost, range, activation, saves, damage, duration, components, conditions, and conservative upcasting metadata.
- Added staged module-facing item workflow hooks and public API.
- Added standard Active Effect support and effect management.
- Added Celestial Spirit Gate Keys, linked summon Actors, limits, costs, upkeep, dismissal, and scaling.
- Added Slayer, Curse/Demon, transformation, boss, defense, and ranked-condition models.
- Added optional lore magic/race content and lore item/loot compendium.
- Added migration support and compatibility-first settings.
- Corrected duplicate legacy compendium document IDs.
- Corrected sourcebook class hit dice/saving throws in the automation configuration.
- Made item-use transactions rollback-safe when a workflow is cancelled or a resource spend fails.
- Made transformation dismissal free and prevented it from consuming limited uses.
- Added automatic resolution for save/condition-only techniques when automatic resolution is enabled.
- Character-builder magic respecs now remove only the stale builder-owned magic-path features/effects from the replaced magic.
- Hardened summon tracking and final package/reference validation.
