export const SYSTEM_ID = "fairy-tail-rewired";
export const SYSTEM_VERSION = "1.0.0";
export const API_VERSION = 1;
export const SCHEMA_VERSION = 7;

export const FTR = {
  abilities: {
    str: "Strength", dex: "Dexterity", con: "Constitution",
    int: "Intelligence", wis: "Wisdom", cha: "Charisma"
  },
  skills: {
    acrobatics: {label:"Acrobatics", ability:"dex"},
    animalHandling: {label:"Animal Handling", ability:"wis"},
    arcana: {label:"Arcana", ability:"int"},
    athletics: {label:"Athletics", ability:"str"},
    deception: {label:"Deception", ability:"cha"},
    history: {label:"History", ability:"int"},
    insight: {label:"Insight", ability:"wis"},
    intimidation: {label:"Intimidation", ability:"cha"},
    investigation: {label:"Investigation", ability:"int"},
    medicine: {label:"Medicine", ability:"wis"},
    nature: {label:"Nature", ability:"int"},
    perception: {label:"Perception", ability:"wis"},
    performance: {label:"Performance", ability:"cha"},
    persuasion: {label:"Persuasion", ability:"cha"},
    religion: {label:"Religion", ability:"int"},
    sleight: {label:"Sleight of Hand", ability:"dex"},
    stealth: {label:"Stealth", ability:"dex"},
    survival: {label:"Survival", ability:"wis"}
  },
  damageTypes: {
    acid:"Acid", bludgeoning:"Bludgeoning", cold:"Cold", fire:"Fire", force:"Force",
    lightning:"Lightning", necrotic:"Necrotic", piercing:"Piercing", poison:"Poison",
    psychic:"Psychic", radiant:"Radiant", slashing:"Slashing", thunder:"Thunder",
    water:"Water", wind:"Wind", earth:"Earth", magic:"Magic", curse:"Curse"
  },
  conditions: {
    silenced: {label:"Silenced", icon:"icons/svg/silenced.svg", ranked:false},
    winded: {label:"Winded", icon:"icons/svg/downgrade.svg", ranked:true},
    burned: {label:"Burned", icon:"icons/svg/fire.svg", ranked:true},
    slowed: {label:"Slowed", icon:"icons/svg/net.svg", ranked:false},
    celestia: {label:"Celestia", icon:"icons/svg/aura.svg", ranked:true},
    concentrating: {label:"Concentrating", icon:"icons/svg/aura.svg", ranked:false},
    starDress: {label:"Star Dress", icon:"icons/svg/upgrade.svg", ranked:false},
    transformed: {label:"Transformed", icon:"icons/svg/wing.svg", ranked:false}
  },
  classProgression: {
    "Brute Force Mage": {hitDie:6, mana:"level2+mod", saves:["int","wis"]},
    "Cauldron": {hitDie:12, mana:"level", saves:["str","wis","con"]},
    "Hidden Mage": {hitDie:10, mana:"level+mod", saves:["dex","int"]},
    "Street Magician": {hitDie:10, mana:"level+mod+prof", saves:["dex","cha"]},
    "Support Mage": {hitDie:8, mana:"level+mod+prof", saves:["dex","wis"]},
    "Tactical Mage": {hitDie:6, mana:"level2+mod", saves:["dex","int"]},
    "Warrior": {hitDie:10, mana:"level", saves:["str","dex","con"]}
  },
  classLogos: {
    "Brute Force Mage":"systems/fairy-tail-rewired/assets/class-logos/brute-force-mage.svg",
    "Cauldron":"systems/fairy-tail-rewired/assets/class-logos/cauldron.svg",
    "Hidden Mage":"systems/fairy-tail-rewired/assets/class-logos/hidden-mage.svg",
    "Street Magician":"systems/fairy-tail-rewired/assets/class-logos/street-magician.svg",
    "Support Mage":"systems/fairy-tail-rewired/assets/class-logos/support-mage.svg",
    "Tactical Mage":"systems/fairy-tail-rewired/assets/class-logos/tactical-mage.svg",
    "Warrior":"systems/fairy-tail-rewired/assets/class-logos/warrior.svg"
  },
  itemTypeIcons: {
    spell:"fa-wand-sparkles", technique:"fa-burst", weapon:"fa-sword", armor:"fa-shield-halved",
    equipment:"fa-toolbox", consumable:"fa-flask", feature:"fa-star", feat:"fa-medal",
    class:"fa-chess-rook", magic:"fa-hat-wizard", race:"fa-people-group", background:"fa-book-open",
    celestialKey:"fa-key", transformation:"fa-mask"
  },
  magicRanks: {0:"Cantrip",1:"1st",2:"2nd",3:"3rd",4:"4th",5:"5th",6:"6th",7:"7th",8:"8th",9:"9th"},
  celestialKeyRanks: {silver:"Silver",gold:"Gold",black:"Black / Unique"},
  actionTypes: {
    utility:"Utility", mwak:"Melee Weapon Attack", rwak:"Ranged Weapon Attack",
    msak:"Melee Spell Attack", rsak:"Ranged Spell Attack", save:"Saving Throw",
    damage:"Damage", heal:"Healing", summon:"Summon", transform:"Transformation"
  },
  activationTypes: {
    action:"Action", bonus:"Bonus Action", reaction:"Reaction", movement:"Movement Action",
    free:"Free Action", passive:"Passive", minute:"Minute", hour:"Hour"
  }
};

export function proficiencyForLevel(level=1) {
  return 2 + Math.floor((Math.max(1, Number(level)) - 1) / 4);
}

export function manaForClass(className, level, magicMod, proficiency) {
  const rule = FTR.classProgression[className]?.mana ?? "level+mod";
  if (rule === "level2+mod") return level * 2 + magicMod;
  if (rule === "level+mod+prof") return level + magicMod + proficiency;
  if (rule === "level") return level;
  return level + magicMod;
}

export function signed(n=0) {
  n = Number(n || 0);
  return n >= 0 ? `+${n}` : `${n}`;
}
