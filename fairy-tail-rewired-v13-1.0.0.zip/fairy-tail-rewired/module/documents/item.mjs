import {SYSTEM_ID} from "../config.mjs";
import {applyTargetedDamage} from "../automation/combat.mjs";
import {summonFromItem, validateSummon} from "../automation/summoning.mjs";
import {FTRWorkflow} from "../automation/workflow.mjs";

export class FTRItem extends Item {
  get manaCost() {
    const legacy = Number(this.system.manaCost||0);
    return Number(this.system.cost?.mana ?? legacy);
  }

  async use(options={}) {
    const actor=this.actor;
    if (!actor) {
      ui.notifications.warn(`${this.name} must be owned by an Actor to use its automation.`);
      return null;
    }
    const workflow=new FTRWorkflow({actor,item:this,options});
    if (!workflow.pre("preValidate")) return null;
    if (Hooks.call("ftr.preUseItem",{actor,item:this,options,workflow}) === false) return null;

    if ((this.system.components?.verbal || this.system.components?.sound) && Number(actor.system.conditions?.silenced||0)>0) {
      ui.notifications.warn(`${actor.name} is Silenced and cannot use ${this.name}.`);
      return null;
    }
    if (this.system.actionType === "summon" || this.type === "celestialKey") {
      const validation=await validateSummon(actor,this);
      workflow.post("postValidate",{validation});
      if (!validation.valid) { ui.notifications.warn(validation.message); return null; }
    } else workflow.post("postValidate");

    const isTransformation=this.system.actionType === "transform" || Boolean(this.system.transformation?.enabled);
    const deactivating=isTransformation && this.#isTransformationActive();
    const castLevel=await this.#resolveCastLevel(options);
    if (castLevel == null) return null;
    workflow.castLevel=castLevel;
    const costs=deactivating ? {mana:0,curse:0,demonPoints:0} : this.#calculateCosts(castLevel);
    workflow.costs=costs;
    if (!workflow.pre("preCost",{castLevel,costs,deactivating})) return null;
    // All cancellable validation/roll hooks execute before committing resources or limited uses.
    // This keeps third-party integrations transactional: a cancelled workflow spends nothing.
    if (!workflow.pre("preRoll",{castLevel,costs,deactivating})) return null;
    if (!(await this.#canSpendCosts(costs))) return null;
    if (!deactivating && !this.#canSpendUse()) return null;
    const commit=await this.#commitCostsAndUse(costs,{spendUse:!deactivating});
    if (!commit) return null;
    workflow.post("postCost",{castLevel,costs});

    try {
      if (this.system.actionType === "summon" || this.type === "celestialKey") {
        const summon=await summonFromItem(actor,this,options);
        workflow.summon=summon;
        if (!summon) {
          await this.#refundCosts(costs,{restoreUse:Boolean(commit?.useSpent),demonGain:Number(commit?.demonGain||0)});
          workflow.cancelled=true;
          return workflow.complete({result:null});
        }
        workflow.post("postRoll",{summon});
        await this.#postUtilityCard({castLevel,costs,extra:`Summoned <strong>${foundry.utils.escapeHTML(summon.name)}</strong>.`});
        workflow.result=summon;
        Hooks.callAll("ftr.useItem",this,{actor,castLevel,costs,summon,workflow});
        return workflow.complete({result:summon});
      }
      if (isTransformation) {
        const result=await this.toggleTransformation();
        workflow.result=result;
        workflow.post("postRoll",{result});
        Hooks.callAll("ftr.useItem",this,{actor,castLevel,costs,result,workflow});
        return workflow.complete({result});
      }

      const result=await this.#resolveAction({castLevel,costs,options,workflow});
      if (result?.cancelled) {
        await this.#refundCosts(costs,{restoreUse:Boolean(commit?.useSpent),demonGain:Number(commit?.demonGain||0)});
        workflow.cancelled=true;
        workflow.result=null;
        return workflow.complete({result:null});
      }
      workflow.result=result;
      workflow.post("postRoll",result ?? {});
      Hooks.callAll("ftr.useItem",this,{actor,castLevel,costs,result,workflow});
      return workflow.complete({result});
    } catch (err) {
      await this.#refundCosts(costs,{restoreUse:Boolean(commit?.useSpent),demonGain:Number(commit?.demonGain||0)});
      workflow.cancelled=true;
      workflow.error=err;
      console.error(`${SYSTEM_ID} | ${this.name} workflow failed and was rolled back`,err);
      ui.notifications.error(`${this.name} failed; spent resources and uses were restored.`);
      return workflow.complete({result:null});
    }
  }

  #isTransformationActive() {
    const actor=this.actor;
    if (!actor) return false;
    const key=`transform-${this.id}`;
    return actor.effects.some(e=>e.getFlag?.(SYSTEM_ID,"transformation")===key);
  }

  async #refundCosts(costs,{restoreUse=false,demonGain=0}={}) {
    for (const [resource,cost] of Object.entries(costs ?? {})) {
      if (Number(cost||0)>0) await this.actor.recoverResource(resource,Number(cost),{reason:`Refund: ${this.name}`});
    }
    if (restoreUse && Number(this.system.uses?.max||0)>0) {
      await this.update({"system.uses.value":Math.min(Number(this.system.uses.max),Number(this.system.uses.value||0)+1)});
    }
    if (demonGain>0) {
      const current=Number(this.actor.system.resources?.demonPoints?.value||0);
      await this.actor.update({"system.resources.demonPoints.value":Math.max(0,current-demonGain)});
    }
  }

  async #canSpendCosts(costs) {
    const actor=this.actor;
    for (const [resource,cost] of Object.entries(costs ?? {})) {
      if (!Number(cost||0)) continue;
      if (Number(actor.system.resources?.[resource]?.value||0) < Number(cost)) {
        ui.notifications.warn(`${actor.name} does not have enough ${resource} to use ${this.name}.`);
        return false;
      }
    }
    return true;
  }

  #canSpendUse() {
    const uses=this.system.uses;
    if (!Number(uses?.max||0)) return true;
    if (Number(uses.value||0) <= 0) { ui.notifications.warn(`${this.name} has no uses remaining.`); return false; }
    return true;
  }

  async #commitCostsAndUse(costs,{spendUse=true}={}) {
    const actor=this.actor;
    const spent=[];
    let useSpent=false;
    let demonGain=0;
    try {
      for (const [resource,cost] of Object.entries(costs ?? {})) {
        if (!Number(cost||0)) continue;
        const ok=await actor.spendResource(resource,Number(cost),{reason:this.name});
        if (!ok) throw new Error(`Unable to spend ${cost} ${resource}.`);
        spent.push([resource,Number(cost)]);
      }
      if (spendUse && Number(this.system.uses?.max||0)>0) {
        await this.update({"system.uses.value":Number(this.system.uses.value||0)-1});
        useSpent=true;
      }
      if (actor.system.slayer?.type?.toLowerCase().includes("devil") && Number(costs?.mana||0)>0) {
        demonGain=Number(costs.mana)*10;
        const current=Number(actor.system.resources.demonPoints.value||0);
        const next=Math.min(100,current+demonGain);
        demonGain=next-current;
        if (demonGain>0) await actor.update({"system.resources.demonPoints.value":next});
      }
      return {spent,useSpent,demonGain};
    } catch (err) {
      console.error(`${SYSTEM_ID} | Failed to commit item use transaction`,err);
      for (const [resource,cost] of spent) await actor.recoverResource(resource,cost,{reason:`Rollback: ${this.name}`});
      if (useSpent) await this.update({"system.uses.value":Math.min(Number(this.system.uses.max),Number(this.system.uses.value||0)+1)});
      if (demonGain>0) {
        const current=Number(actor.system.resources.demonPoints.value||0);
        await actor.update({"system.resources.demonPoints.value":Math.max(0,current-demonGain)});
      }
      ui.notifications.error(`${this.name} could not be committed; resources were rolled back.`);
      return null;
    }
  }

  async #resolveCastLevel(options={}) {
    const base = Number(this.system.level||0);
    if (!this.system.upcast?.enabled || Number(this.system.upcast.maxLevel||base) <= base) return base;
    if (Number.isFinite(Number(options.castLevel))) return Math.max(base,Math.min(Number(options.castLevel),Number(this.system.upcast.maxLevel)));
    return new Promise(resolve => {
      const max = Number(this.system.upcast.maxLevel||base);
      let opts="";
      for (let i=base;i<=max;i++) opts += `<option value="${i}">${i}</option>`;
      new Dialog({title:`Cast ${this.name}`,content:`<div class="form-group"><label>Technique Level</label><select name="level">${opts}</select></div>`,buttons:{cast:{label:"Cast",callback:html=>resolve(Number(html.find('[name="level"]').val()))},cancel:{label:"Cancel",callback:()=>resolve(null)}},default:"cast",close:()=>resolve(null)}).render(true);
    });
  }

  #calculateCosts(castLevel) {
    const actor = this.actor;
    const baseLevel = Number(this.system.level||0);
    const extra = Math.max(0,Number(castLevel)-baseLevel);
    const reduction = Number(actor.system.magic?.magicCircleReduction||0);
    const manaBase = Math.max(Number(this.system.cost?.mana||0), Number(this.system.manaCost||0), Number(this.system.transformation?.manaCost||0));
    const mana = Math.max(0, manaBase + extra*Number(this.system.upcast?.manaPerLevel||0) - reduction);
    const curse = Math.max(0, Number(this.system.cost?.curse||0) || Number(this.system.curseCost||0));
    const demonPoints = Math.max(0, Number(this.system.cost?.demonPoints||0));
    return {mana,curse,demonPoints};
  }


  async #resolveAction({castLevel,costs,options,workflow=null}) {
    const actor=this.actor;
    const rollData=actor.getRollData();
    const actionType=String(this.system.actionType||"utility");
    let attackRoll=null;
    if (["mwak","rwak","msak","rsak"].includes(actionType)) {
      let bonus=Number(this.system.attackBonus||0);
      if (["msak","rsak"].includes(actionType)) bonus += Number(actor.system.magic.attack||0);
      else {
        const ability=this.system.ability && this.system.ability !== "magic" ? this.system.ability : "str";
        bonus += Number(actor.system.abilities?.[ability]?.mod||0) + (this.system.weapon?.proficient ? Number(actor.system.proficiency||0) : 0);
      }
      attackRoll=await new Roll(`1d20 + ${bonus}`,rollData).evaluate();
    }

    const damage=[];
    const extraLevels=Math.max(0,Number(castLevel)-Number(this.system.level||0));
    for (const part of (this.system.damage?.parts ?? [])) {
      let formula=String(part.formula||"");
      if (!formula) continue;
      const extra=String(this.system.upcast?.damagePerLevel||"");
      if (extraLevels && extra) formula=`(${formula}) + (${extraLevels} * (${extra}))`;
      const roll=await new Roll(formula,rollData).evaluate();
      damage.push({roll,total:roll.total,type:part.type||"magic"});
    }

    const healing = Boolean(this.system.damage?.healing) || actionType === "heal";
    const targets = Array.from(game.user.targets ?? []);
    if (workflow) workflow.targets=targets;
    const flagTargets = targets.map(t=>t.actor?.uuid).filter(Boolean);
    const content=await renderTemplate(`systems/${SYSTEM_ID}/templates/chat/item-card.hbs`,{
      item:this, actor, castLevel, costs, attackRoll, damage, healing,
      saveDc:Number(this.system.save?.dc||actor.system.magic.dc), saveAbility:this.system.save?.ability,
      targets:targets.map(t=>t.name), hasTargets:targets.length>0, actionType
    });
    if (workflow && !workflow.pre("preMessage",{attackRoll,damage,targets})) return {attackRoll,damage,message:null,cancelled:true};
    const message=await ChatMessage.create({speaker:ChatMessage.getSpeaker({actor}),content,flags:{[SYSTEM_ID]:{
      actorUuid:actor.uuid,itemUuid:this.uuid,targets:flagTargets,
      damage:damage.map(d=>({total:d.total,type:d.type})),healing,
      save:{ability:this.system.save?.ability||"",dc:Number(this.system.save?.dc||actor.system.magic.dc),onSuccess:this.system.save?.onSuccess||"half"},
      condition:{key:this.system.automation?.condition||"",rank:Number(this.system.automation?.conditionRank||0),on:this.system.automation?.conditionOn||"failedSave"}
    }}});

    if (workflow) workflow.post("postMessage",{message,attackRoll,damage,targets});
    const condition=this.system.automation ?? {};
    const hasAutomatedEffect=damage.length>0 || (condition.condition && Number(condition.conditionRank||0)>0);
    if (game.settings.get(SYSTEM_ID,"autoApplyDamage") && targets.length && hasAutomatedEffect && !healing && (!workflow || workflow.pre("preApply",{message,attackRoll,damage,targets}))) {
      const saveAbility=this.system.save?.ability || "";
      if (saveAbility) {
        const dc=Number(this.system.save?.dc||actor.system.magic.dc);
        for (const token of targets) {
          const target=token.actor ?? token;
          if (!target) continue;
          const roll=await target.rollSave(saveAbility,{dc,label:`${this.name} Save`});
          const success=Number(roll?.total||0) >= dc;
          for (const d of damage) {
            let amount=Number(d.total||0);
            if (success && this.system.save?.onSuccess === "half") amount=Math.floor(amount/2);
            if (success && this.system.save?.onSuccess === "none") amount=0;
            if (amount>0) await applyTargetedDamage({source:actor,targets:[target],amount,type:d.type,item:this});
          }
          const applyCondition=condition.condition && Number(condition.conditionRank||0)>0 && (condition.conditionOn === "always" || (condition.conditionOn === "failedSave" && !success));
          if (applyCondition) await target.setRankedCondition(condition.condition,Number(condition.conditionRank),{additive:true,dc,sourceUuid:this.uuid});
        }
      } else {
        const resolvedTargets=attackRoll ? targets.filter(t=>Number(attackRoll.total||0) >= Number((t.actor??t).system?.attributes?.ac?.value||10)) : targets;
        for (const d of damage) await applyTargetedDamage({source:actor,targets:resolvedTargets,amount:d.total,type:d.type,item:this});
        if (condition.condition && Number(condition.conditionRank||0)>0 && ["hit","always"].includes(condition.conditionOn)) {
          for (const token of resolvedTargets) {
            const target=token.actor ?? token;
            if (target?.setRankedCondition) await target.setRankedCondition(condition.condition,Number(condition.conditionRank),{additive:true,sourceUuid:this.uuid});
          }
        }
      }
      if (workflow) workflow.post("postApply",{message,attackRoll,damage,targets});
    }
    return {message,attackRoll,damage};
  }

  async #postUtilityCard({castLevel,costs,extra=""}={}) {
    const content=await renderTemplate(`systems/${SYSTEM_ID}/templates/chat/item-card.hbs`,{item:this,actor:this.actor,castLevel,costs,attackRoll:null,damage:[],healing:false,extra,targets:[],hasTargets:false,actionType:this.system.actionType});
    return ChatMessage.create({speaker:ChatMessage.getSpeaker({actor:this.actor}),content});
  }

  async toggleTransformation() {
    const actor=this.actor;
    if (!actor) return false;
    const key=`transform-${this.id}`;
    const existing=actor.effects.find(e=>e.getFlag(SYSTEM_ID,"transformation")===key);
    if (existing) { await existing.delete(); return false; }
    const t=this.system.transformation;
    const changes=[];
    const ADD=CONST.ACTIVE_EFFECT_MODES.ADD;
    if (t.acBonus) changes.push({key:"system.attributes.ac.bonus",mode:ADD,value:String(t.acBonus),priority:20});
    if (t.speedBonus) changes.push({key:"system.movement.bonus",mode:ADD,value:String(t.speedBonus),priority:20});
    if (t.magicAttackBonus) changes.push({key:"system.magic.attackBonus",mode:ADD,value:String(t.magicAttackBonus),priority:20});
    if (t.magicDcBonus) changes.push({key:"system.magic.dcBonus",mode:ADD,value:String(t.magicDcBonus),priority:20});
    const data={name:t.name||this.name,img:this.img,statuses:["ftr-transformed"],changes,duration:{rounds:Number(t.durationRounds||10)},flags:{[SYSTEM_ID]:{transformation:key,sourceItemUuid:this.uuid}}};
    const [effect]=await actor.createEmbeddedDocuments("ActiveEffect",[data]);
    if (t.resistance) {
      const resistance=String(t.resistance);
      const before=actor.system.defenses.resistances??[];
      const wasNew=!before.includes(resistance);
      if (wasNew) await actor.update({"system.defenses.resistances":Array.from(new Set([...before,resistance]))});
      await effect.setFlag(SYSTEM_ID,"addedResistance",{value:resistance,wasNew});
    }
    return effect;
  }
}
