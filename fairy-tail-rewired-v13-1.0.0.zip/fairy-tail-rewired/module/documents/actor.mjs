import {FTR, SYSTEM_ID} from "../config.mjs";
import {abilityRoll, saveRoll, skillRoll} from "../automation/rolls.mjs";
import {mitigationFor} from "../automation/combat.mjs";
import {setRankedCondition, clearCondition, attemptConditionRecovery} from "../automation/conditions.mjs";

export class FTRActor extends Actor {
  getRollData() {
    const data = super.getRollData?.() ?? {};
    data.abilities = this.system.abilities;
    data.skills = this.system.skills;
    data.resources = this.system.resources;
    data.attributes = this.system.attributes;
    data.magic = this.system.magic;
    data.level = this.system.level;
    data.prof = this.system.proficiency;
    return data;
  }

  async rollAbility(ability, options={}) { return abilityRoll(this, ability, options); }
  async rollSave(ability, options={}) { return saveRoll(this, ability, options); }
  async rollSkill(skill, options={}) { return skillRoll(this, skill, options); }

  async spendResource(resource, amount=0, {reason=""}={}) {
    const res = this.system.resources?.[resource];
    amount = Math.max(0, Number(amount||0));
    if (!res) return false;
    if (Number(res.value||0) < amount) return false;
    await this.update({[`system.resources.${resource}.value`]:Math.max(0,Number(res.value)-amount)});
    Hooks.callAll("ftr.resourceSpent", this, resource, amount, reason);
    return true;
  }

  async recoverResource(resource, amount=0, {reason=""}={}) {
    const res = this.system.resources?.[resource];
    amount = Math.max(0, Number(amount||0));
    if (!res) return false;
    const max = Number(res.max||0);
    const value = Math.min(max, Number(res.value||0)+amount);
    await this.update({[`system.resources.${resource}.value`]:value});
    Hooks.callAll("ftr.resourceRecovered", this, resource, amount, reason);
    return value;
  }

  async applyDamage(amount, type="", {source=""}={}) {
    const final = mitigationFor(this, amount, type);
    const hp = this.system.resources.hp;
    const temp = Number(hp.temp||0);
    const absorb = Math.min(temp, final);
    const remaining = final - absorb;
    const updates = {"system.resources.hp.temp":Math.max(0,temp-absorb)};
    updates["system.resources.hp.value"] = Math.max(0, Number(hp.value||0)-remaining);
    await this.update(updates);
    Hooks.callAll("ftr.damageApplied", this, {requested:Number(amount||0), applied:final, type, source});
    return final;
  }

  async heal(amount, {source=""}={}) {
    amount = Math.max(0, Math.floor(Number(amount||0)));
    const hp = this.system.resources.hp;
    const before = Number(hp.value||0);
    const after = Math.min(Number(hp.max||0), before + amount);
    await this.update({"system.resources.hp.value":after});
    Hooks.callAll("ftr.healingApplied", this, {requested:amount, applied:after-before, source});
    return after-before;
  }

  async setRankedCondition(key, rank=1, options={}) { return setRankedCondition(this,key,rank,options); }
  async clearCondition(key) { return clearCondition(this,key); }
  async recoverCondition(key) { return attemptConditionRecovery(this,key); }

  async slayerDevour({amount=null, resource="mana"}={}) {
    if (!this.system.slayer?.devourEnabled) {
      ui.notifications.warn(`${this.name} does not have Slayer Devour enabled.`);
      return false;
    }
    if (amount == null) {
      amount = await promptNumber("Slayer Devour", "How much matching elemental power is consumed?", 1, 0);
      if (amount == null) return false;
    }
    const recovered = await this.recoverResource(resource, Number(amount||0), {reason:`${this.system.slayer.type || "Slayer"} Devour`});
    const roll = await new Roll("1d20 + @abilities.con.mod", this.getRollData()).evaluate();
    await roll.toMessage({speaker:ChatMessage.getSpeaker({actor:this}), flavor:`<strong>${this.system.slayer.type || "Slayer"} Devour</strong> — restored ${recovered} ${resource}`});
    return recovered;
  }

  async shortRest() {
    const mana = Math.max(1, Number(this.system.proficiency||2));
    await this.recoverResource("mana", mana, {reason:"Short Rest"});
    for (const item of this.items) if (item.system.uses?.per === "shortRest") await item.update({"system.uses.value":item.system.uses.max});
    Hooks.callAll("ftr.shortRest",this);
  }

  async longRest() {
    const updates = {
      "system.resources.hp.value":this.system.resources.hp.max,
      "system.resources.mana.value":this.system.resources.mana.max,
      "system.resources.curse.value":this.system.resources.curse.max,
      "system.resources.demonPoints.value":0,
      "system.attributes.exhaustion":Math.max(0, Number(this.system.attributes.exhaustion||0)-1)
    };
    await this.update(updates);
    for (const item of this.items) if (["shortRest","longRest","day"].includes(item.system.uses?.per)) await item.update({"system.uses.value":item.system.uses.max});
    Hooks.callAll("ftr.longRest",this);
  }

  async useItem(itemId, options={}) {
    const item = this.items.get(itemId);
    return item?.use?.(options);
  }

  async recordAdvancement({type="manual",summary="",data={}}={}) {
    const current=[...(this.system.advancement?.history ?? [])];
    current.push({timestamp:Date.now(),type:String(type||"manual"),summary:String(summary||""),data:JSON.stringify(data ?? {})});
    const history=current.slice(-50);
    await this.update({"system.advancement.history":history});
    Hooks.callAll("ftr.advancementRecorded",this,history.at(-1));
    return history.at(-1);
  }

  async toggleSlayerForm() {
    const active = !Boolean(this.system.slayer?.formActive);
    await this.update({"system.slayer.formActive":active});
    return active;
  }
}

async function promptNumber(title, label, initial=0, min=0) {
  return new Promise(resolve => {
    new Dialog({
      title,
      content:`<div class="form-group"><label>${foundry.utils.escapeHTML(label)}</label><input type="number" name="value" value="${Number(initial)}" min="${Number(min)}" /></div>`,
      buttons:{
        ok:{label:"OK",callback:html=>resolve(Number(html.find('[name="value"]').val()||0))},
        cancel:{label:"Cancel",callback:()=>resolve(null)}
      },
      default:"ok",
      close:()=>resolve(null)
    }).render(true);
  });
}
