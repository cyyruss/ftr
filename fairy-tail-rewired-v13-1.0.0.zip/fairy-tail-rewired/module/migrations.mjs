import {SYSTEM_ID, SCHEMA_VERSION} from "./config.mjs";

export async function migrateWorld() {
  if (!game.user.isGM) return;
  const current=Number(game.settings.get(SYSTEM_ID,"schemaVersion")||0);
  if (current >= SCHEMA_VERSION) return;
  ui.notifications.info(`Fairy Tail: Rewired is migrating world data to schema ${SCHEMA_VERSION}.`);
  for (const actor of game.actors) await migrateActor(actor);
  for (const item of game.items) await migrateItem(item);
  await game.settings.set(SYSTEM_ID,"schemaVersion",SCHEMA_VERSION);
  ui.notifications.info("Fairy Tail: Rewired migration complete.");
}

async function migrateActor(actor) {
  const raw=actor._source?.system ?? {};
  const update={};
  if (raw.race && !actor.system.details?.race) update["system.details.race"]=raw.race;
  if (raw.className && !actor.system.details?.class) update["system.details.class"]=raw.className;
  if (typeof raw.magic === "string" && !actor.system.magic?.primary) update["system.magic.primary"]=raw.magic;
  if (Number(raw.resources?.hp?.max||0) && !Number(actor.system.resources?.hp?.overrideMax||0)) update["system.resources.hp.overrideMax"]=Number(raw.resources.hp.max);
  if (Number(raw.resources?.mana?.max||0) && !Number(actor.system.resources?.mana?.overrideMax||0)) update["system.resources.mana.overrideMax"]=Number(raw.resources.mana.max);
  if (Number(raw.ac||0) && !Number(actor.system.attributes?.ac?.override||0)) update["system.attributes.ac.override"]=Number(raw.ac);
  if (Number(raw.speed||0) && Number(actor.system.movement?.walk||30)===30) update["system.movement.walk"]=Number(raw.speed);
  update["system.schemaVersion"]=SCHEMA_VERSION;
  if (Object.keys(update).length) await actor.update(update,{diff:false});
  for (const item of actor.items) await migrateItem(item);
}

async function migrateItem(item) {
  const raw=item._source?.system ?? {};
  const update={"system.schemaVersion":SCHEMA_VERSION};
  if (raw.manaCost != null && !Number(item.system.cost?.mana||0)) update["system.cost.mana"]=Number(raw.manaCost||0);
  if (raw.curseCost != null && !Number(item.system.cost?.curse||0)) update["system.cost.curse"]=Number(raw.curseCost||0);
  if (typeof raw.damage === "string" && raw.damage.trim() && !(item.system.damage?.parts?.length)) update["system.damage.parts"]=[{formula:raw.damage.trim(),type:"magic"}];
  if (typeof raw.range === "string" && raw.range.trim() && !item.system.range?.text) update["system.range.text"]=raw.range.trim();
  await item.update(update,{diff:false});
}
