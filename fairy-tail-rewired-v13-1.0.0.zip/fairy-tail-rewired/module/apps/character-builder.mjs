import {FTR, SYSTEM_ID} from "../config.mjs";
import {openMagicProgression} from "./progression-app.mjs";
import {pendingMagicChoices, removeMagicChoice, slugifyMagic} from "../progression/progression.mjs";

const {ApplicationV2, HandlebarsApplicationMixin} = foundry.applications.api;

const CHOICE_PACKS = {
  race: [`${SYSTEM_ID}.races`, `${SYSTEM_ID}.lore-races`],
  class: [`${SYSTEM_ID}.classes`],
  magic: [`${SYSTEM_ID}.magics`, `${SYSTEM_ID}.lore-magics`],
  background: [`${SYSTEM_ID}.backgrounds`]
};

async function packChoices(packIds, type) {
  const choices=[];
  for (const packId of packIds) {
    const pack=game.packs.get(packId);
    if (!pack) continue;
    const index=await pack.getIndex({fields:["name","type","system.loreTag","system.source"]});
    for (const row of index) {
      if (type && row.type !== type) continue;
      choices.push({
        value:`${packId}|${row._id}`,
        id:row._id,
        packId,
        name:row.name,
        loreTag:row.system?.loreTag ?? (packId.includes("lore-") ? "lore" : "rewired"),
        source:row.system?.source ?? ""
      });
    }
  }
  return choices.sort((a,b)=>a.name.localeCompare(b.name));
}

async function resolveChoice(value) {
  if (!value || !String(value).includes("|")) return null;
  const [packId,id]=String(value).split("|");
  const pack=game.packs.get(packId);
  if (!pack) return null;
  const doc=await pack.getDocument(id);
  return doc ? {doc,packId} : null;
}

function documentSourceData(doc, packId) {
  const data=doc.toObject();
  delete data._id;
  delete data.folder;
  data.flags ??= {};
  data.flags[SYSTEM_ID] = {
    ...(data.flags[SYSTEM_ID] ?? {}),
    builderManaged:true,
    sourceUuid:doc.uuid,
    sourcePack:packId
  };
  return data;
}

function inferSlayer(raceName="",magicName="") {
  const race=String(raceName), magic=String(magicName), name=`${race} ${magic}`;
  let result=null;
  if (/dragon eater|fifth generation/i.test(race)) result={type:"Dragon Slayer",generation:5,devourEnabled:true,targetTag:"dragon"};
  else if (/fourth generation/i.test(race)) result={type:"Dragon Slayer",generation:4,devourEnabled:false,targetTag:"dragon"};
  else if (/dragon slayer/i.test(name)) result={type:"Dragon Slayer",generation:1,devourEnabled:true,targetTag:"dragon"};
  else if (/god slayer/i.test(name)) result={type:"God Slayer",generation:1,devourEnabled:true,targetTag:"god"};
  else if (/devil slayer/i.test(name)) result={type:"Devil Slayer",generation:1,devourEnabled:true,targetTag:"demon"};
  if (!result) return null;
  const element=magic.match(/^(Fire|Sky|Iron|Lightning|Poison|Shadow|White|Ice|Water|Earth|Wind|Light|Darkness)\b/i)?.[1] ?? "";
  return {...result,element};
}

export class CharacterBuilder extends HandlebarsApplicationMixin(ApplicationV2) {
  static DEFAULT_OPTIONS = {
    id:"ftr-character-builder",
    tag:"form",
    classes:["fairy-tail-rewired","ftr-builder-app"],
    window:{title:"Fairy Tail: Rewired — Character Builder",icon:"fa-solid fa-wand-sparkles",resizable:true},
    position:{width:760,height:760},
    actions:{
      apply:CharacterBuilder._apply,
      preview:CharacterBuilder._preview,
      openSheet:CharacterBuilder._openSheet,
      openPaths:CharacterBuilder._openPaths
    }
  };

  static PARTS = {
    main:{template:`systems/${SYSTEM_ID}/templates/apps/character-builder.hbs`,scrollable:[".ftr-builder-scroll"]}
  };

  constructor(actor, options={}) {
    super(options);
    this.actor=actor;
    this._previewText="";
    this._draft=null;
  }

  get title() { return `Character Builder — ${this.actor?.name ?? "New Wizard"}`; }

  async _prepareContext(options) {
    const actor=this.actor;
    const [races,classes,magics,backgrounds]=await Promise.all([
      packChoices(CHOICE_PACKS.race,"race"), packChoices(CHOICE_PACKS.class,"class"),
      packChoices(CHOICE_PACKS.magic,"magic"), packChoices(CHOICE_PACKS.background,"background")
    ]);
    const findCurrent=(list,name)=>list.find(c=>c.name===name)?.value ?? "";
    const selected={
      race:this._draft?.race ?? findCurrent(races,actor.system.details?.race),
      class:this._draft?.class ?? findCurrent(classes,actor.system.details?.class),
      magic:this._draft?.magic ?? findCurrent(magics,actor.system.magic?.primary),
      background:this._draft?.background ?? findCurrent(backgrounds,actor.system.details?.background)
    };
    const bg=await resolveChoice(selected.background);
    const skillKeys=bg?.doc?.system?.backgroundData?.skillChoices ?? [];
    const backgroundSkills=skillKeys.map(key=>({key,label:FTR.skills[key]?.label ?? key}));
    return {
      actor,
      system:actor.system,
      draft:{
        name:this._draft?.name ?? actor.name,
        level:this._draft?.level ?? actor.system.level,
        guild:this._draft?.guild ?? actor.system.details?.guild ?? "",
        rank:this._draft?.rank ?? actor.system.details?.rank ?? "",
        magicAbility:this._draft?.magicAbility ?? actor.system.magic?.ability ?? "int",
        slayerElement:this._draft?.slayerElement ?? actor.system.slayer?.element ?? "",
        backgroundSkill1:this._draft?.backgroundSkill1 ?? "",
        backgroundSkill2:this._draft?.backgroundSkill2 ?? ""
      },
      abilities:Object.entries(FTR.abilities).map(([key,label])=>({key,label,value:Number(this._draft?.[`ability-${key}`] ?? actor.system.abilities?.[key]?.value ?? 10)})),
      races,classes,magics,backgrounds,selected,backgroundSkills,
      backgroundFeature:bg?.doc?.system?.backgroundData?.featureName ?? "",
      backgroundStartingCash:bg?.doc?.system?.backgroundData?.startingCash ?? 0,
      magicAbilities:FTR.abilities,
      previewText:this._previewText,
      history:[...(actor.system.advancement?.history ?? [])].slice(-8).reverse()
    };
  }

  _formValues() {
    const fd=new FormData(this.element);
    return Object.fromEntries(fd.entries());
  }

  static async _preview(event,target) {
    event.preventDefault();
    const values=this._formValues();
    this._draft=values;
    const resolved=await Promise.all([resolveChoice(values.race),resolveChoice(values.class),resolveChoice(values.magic),resolveChoice(values.background)]);
    const names=resolved.map(r=>r?.doc?.name ?? "—");
    const extras=[];
    if (names[2]==="Celestial Spirit Magic") extras.push("Celestial Spirit controls will be enabled.");
    const slayer=inferSlayer(names[0],names[2]);
    if (slayer) extras.push(`${slayer.type} automation will be enabled (generation ${slayer.generation}).`);
    extras.push("Magic path choices are tracked at Rewired progression milestones and can be opened after applying the build.");
    this._previewText=`${values.name || this.actor.name}: ${names[0]} • ${names[1]} • ${names[2]} • ${names[3]}. ${extras.join(" ")}`;
    this.render({force:true});
  }

  static async _apply(event,target) {
    event.preventDefault();
    if (!this.actor?.isOwner) return ui.notifications.warn("You do not have permission to build this character.");
    const values=this._formValues();
    const [raceChoice,classChoice,magicChoice,backgroundChoice]=await Promise.all([
      resolveChoice(values.race),resolveChoice(values.class),resolveChoice(values.magic),resolveChoice(values.background)
    ]);
    if (!raceChoice || !classChoice || !magicChoice || !backgroundChoice) {
      return ui.notifications.warn("Choose a race/origin, class, magic, and background before applying the build.");
    }

    const abilityUpdates={};
    for (const key of Object.keys(FTR.abilities)) {
      const n=Number(values[`ability-${key}`]);
      if (Number.isFinite(n)) abilityUpdates[`system.abilities.${key}.value`]=Math.max(1,Math.min(30,Math.floor(n)));
    }
    const level=Math.max(1,Math.min(30,Number(values.level)||1));
    const updates={
      name:String(values.name||this.actor.name).trim() || this.actor.name,
      "system.level":level,
      "system.details.race":raceChoice.doc.name,
      "system.details.class":classChoice.doc.name,
      "system.details.background":backgroundChoice.doc.name,
      "system.details.guild":String(values.guild||""),
      "system.details.rank":String(values.rank||""),
      "system.magic.primary":magicChoice.doc.name,
      "system.magic.ability":Object.hasOwn(FTR.abilities,values.magicAbility) ? values.magicAbility : "int",
      "system.summoning.celestialMage":magicChoice.doc.name === "Celestial Spirit Magic",
      ...abilityUpdates
    };
    const classInfo=FTR.classProgression[classChoice.doc.name];
    const previousBuilder=this.actor.getFlag(SYSTEM_ID,"builderManaged") ?? {};
    const previousSaves=Array.isArray(previousBuilder.saveProficiencies) ? previousBuilder.saveProficiencies : [];
    const nextSaves=classInfo?.saves ?? [];
    // Remove only save proficiencies that the previous builder pass owned, then apply the new class set.
    for (const key of previousSaves) if (!nextSaves.includes(key)) updates[`system.abilities.${key}.saveProficient`]=false;
    for (const key of nextSaves) updates[`system.abilities.${key}.saveProficient`]=true;

    const allowedSkills=backgroundChoice.doc.system?.backgroundData?.skillChoices ?? [];
    const skillCount=Number(backgroundChoice.doc.system?.backgroundData?.skillCount ?? 0);
    const chosenSkills=[values.backgroundSkill1,values.backgroundSkill2].filter(Boolean);
    if (skillCount && chosenSkills.length < skillCount) return ui.notifications.warn(`Choose ${skillCount} background skill proficiencies.`);
    if (new Set(chosenSkills).size !== chosenSkills.length) return ui.notifications.warn("Choose different background skills.");
    if (chosenSkills.some(k=>!allowedSkills.includes(k))) return ui.notifications.warn("One of the selected background skills is not granted by that background.");
    const previousSkills=Array.isArray(previousBuilder.backgroundSkills) ? previousBuilder.backgroundSkills : [];
    for (const key of previousSkills) {
      if (!chosenSkills.includes(key) && Number(this.actor.system.skills?.[key]?.rank||0) === 1) updates[`system.skills.${key}.rank`]=0;
    }
    for (const key of chosenSkills) updates[`system.skills.${key}.rank`]=Math.max(1,Number(this.actor.system.skills?.[key]?.rank||0));

    const slayer=inferSlayer(raceChoice.doc.name,magicChoice.doc.name);
    if (slayer) {
      updates["system.slayer.type"]=slayer.type;
      updates["system.slayer.generation"]=slayer.generation;
      updates["system.slayer.devourEnabled"]=slayer.devourEnabled;
      updates["system.slayer.targetTag"]=slayer.targetTag;
      updates["system.slayer.element"]=String(values.slayerElement || slayer.element || "");
    } else {
      updates["system.slayer.type"]=""; updates["system.slayer.generation"]=0; updates["system.slayer.devourEnabled"]=false; updates["system.slayer.targetTag"]=""; updates["system.slayer.element"]="";
    }
    await this.actor.update(updates);
    await this.actor.setFlag(SYSTEM_ID,"builderManaged",{saveProficiencies:[...nextSaves],backgroundSkills:[...chosenSkills]});

    const selected=[raceChoice,classChoice,magicChoice,backgroundChoice];
    const selectedTypes=new Set(selected.map(x=>x.doc.type));
    const obsolete=this.actor.items.filter(i=>selectedTypes.has(i.type) && i.getFlag(SYSTEM_ID,"builderManaged"));
    const replacedMagicKeys=new Set(obsolete.filter(i=>i.type==="magic" && i.name!==magicChoice.doc.name).map(i=>slugifyMagic(i.name)));
    if (replacedMagicKeys.size) {
      const stalePathFeatures=this.actor.items.filter(i=>{
        const flag=i.getFlag(SYSTEM_ID,"progressionChoice");
        return flag && replacedMagicKeys.has(flag.magicKey);
      });
      for (const feature of stalePathFeatures) await removeMagicChoice(this.actor,feature);
    }
    if (obsolete.length) await this.actor.deleteEmbeddedDocuments("Item",obsolete.map(i=>i.id));
    await this.actor.createEmbeddedDocuments("Item",selected.map(x=>documentSourceData(x.doc,x.packId)));

    if (this.actor.recordAdvancement) await this.actor.recordAdvancement({
      type:"builder",
      summary:`Builder applied: ${raceChoice.doc.name}; ${classChoice.doc.name}; ${magicChoice.doc.name}; ${backgroundChoice.doc.name}`,
      data:{level,race:raceChoice.doc.name,class:classChoice.doc.name,magic:magicChoice.doc.name,background:backgroundChoice.doc.name,skills:chosenSkills}
    });
    Hooks.callAll("ftr.builderApplied",this.actor,{values,race:raceChoice.doc,class:classChoice.doc,magic:magicChoice.doc,background:backgroundChoice.doc});
    const pending=pendingMagicChoices(this.actor).length;
    ui.notifications.info(`${this.actor.name} was updated by the Fairy Tail: Rewired character builder.${pending ? ` ${pending} magic path choice(s) are ready.` : ""}`);
    this.actor.sheet?.render(true);
    this._previewText=`Build applied successfully. Existing hand-created items and notes were preserved.${pending ? ` ${pending} magic path choice(s) are ready.` : ""}`;
    this.render({force:true});
    if (pending) openMagicProgression(this.actor);
  }

  static _openPaths(event,target) { event.preventDefault(); return openMagicProgression(this.actor); }

  static _openSheet(event,target) {
    event.preventDefault();
    this.actor?.sheet?.render(true);
  }
}

export function openCharacterBuilder(actor) {
  if (!actor) return ui.notifications.warn("Select or provide a character Actor first.");
  if (actor.type !== "character") return ui.notifications.warn("The character builder is only available for character Actors.");
  const app=new CharacterBuilder(actor);
  app.render({force:true});
  return app;
}
