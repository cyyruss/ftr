import {SYSTEM_ID} from "../config.mjs";
import {actorMagicItems, progressionStatus, applyMagicChoice} from "../progression/progression.mjs";

const {ApplicationV2, HandlebarsApplicationMixin}=foundry.applications.api;

export class MagicProgressionApp extends HandlebarsApplicationMixin(ApplicationV2) {
  static DEFAULT_OPTIONS={
    id:"ftr-magic-progression",
    tag:"div",
    classes:["fairy-tail-rewired","ftr-progression-app"],
    window:{title:"Fairy Tail: Rewired — Magic Paths",icon:"fa-solid fa-code-branch",resizable:true},
    position:{width:880,height:720},
    actions:{choose:MagicProgressionApp._choose,openSheet:MagicProgressionApp._openSheet}
  };
  static PARTS={main:{template:`systems/${SYSTEM_ID}/templates/apps/progression-app.hbs`,scrollable:[".ftr-progression-scroll"]}};

  constructor(actor,options={}) { super(options); this.actor=actor; }
  get title(){ return `Magic Paths — ${this.actor?.name ?? "Wizard"}`; }

  async _prepareContext() {
    const magics=actorMagicItems(this.actor).map(magic=>{
      const s=progressionStatus(this.actor,magic);
      return {
        id:magic.id,name:magic.name,img:magic.img,source:s.progression.source,
        milestones:s.milestones.map(m=>({
          ...m,
          selectedName:m.selected?.item?.name ?? "",
          choices:m.choices.map(c=>({...c,requiresText:(c.requires??[]).join(", ")}))
        })),
        pendingCount:s.pending.length
      };
    });
    return {actor:this.actor,level:this.actor.system.level,magics,empty:magics.length===0,pendingCount:magics.reduce((n,m)=>n+m.pendingCount,0)};
  }

  static async _choose(event,target) {
    event.preventDefault();
    const magic=this.actor.items.get(target.dataset.magicId);
    if (!magic) return ui.notifications.warn("The magic item is no longer on this character.");
    try {
      const result=await applyMagicChoice(this.actor,magic,target.dataset.milestoneId,target.dataset.choiceId);
      ui.notifications.info(`${this.actor.name} learned ${result.choice.name}.`);
      await this.render({force:true});
      this.actor.sheet?.render(false);
    } catch (err) { ui.notifications.error(err.message); }
  }
  static _openSheet(event,target){ event.preventDefault(); this.actor?.sheet?.render(true); }
}

export function openMagicProgression(actor){
  if (!actor) return ui.notifications.warn("Provide a character Actor first.");
  if (actor.type!=="character") return ui.notifications.warn("Magic path advancement is for character Actors.");
  const app=new MagicProgressionApp(actor); app.render({force:true}); return app;
}
