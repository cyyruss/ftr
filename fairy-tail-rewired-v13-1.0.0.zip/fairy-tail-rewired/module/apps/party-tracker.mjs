import {FTR, SYSTEM_ID} from "../config.mjs";
import {openCharacterBuilder} from "./character-builder.mjs";
import {openMagicProgression} from "./progression-app.mjs";
import {pendingMagicChoices} from "../progression/progression.mjs";

const {ApplicationV2, HandlebarsApplicationMixin} = foundry.applications.api;

function percent(value,max) {
  if (!Number(max)) return 0;
  return Math.max(0,Math.min(100,Math.round((Number(value||0)/Number(max))*100)));
}

export class PartyTracker extends HandlebarsApplicationMixin(ApplicationV2) {
  static DEFAULT_OPTIONS = {
    id:"ftr-party-tracker",
    tag:"div",
    classes:["fairy-tail-rewired","ftr-party-tracker-app"],
    window:{title:"Fairy Tail: Rewired — Party Tracker",icon:"fa-solid fa-people-group",resizable:true},
    position:{width:900,height:650},
    actions:{
      openActor:PartyTracker._openActor,
      openBuilder:PartyTracker._openBuilder,
      openPaths:PartyTracker._openPaths,
      shortRest:PartyTracker._shortRest,
      longRest:PartyTracker._longRest,
      refresh:PartyTracker._refresh
    }
  };
  static PARTS = {main:{template:`systems/${SYSTEM_ID}/templates/apps/party-tracker.hbs`,scrollable:[".ftr-tracker-scroll"]}};

  async _prepareContext(options) {
    const actors=(game.actors?.contents ?? []).filter(a=>a.type==="character" && (game.user.isGM || a.isOwner));
    const rows=actors.map(actor=>{
      const s=actor.system;
      const conditions=Object.entries(FTR.conditions)
        .filter(([key])=>Number(s.conditions?.[key]||0)>0)
        .map(([key,cfg])=>`${cfg.label}${Number(s.conditions[key])>1?` ${s.conditions[key]}`:""}`);
      const summons=(game.actors?.contents ?? []).filter(a=>a.type==="summon" && a.getFlag(SYSTEM_ID,"summonerUuid")===actor.uuid);
      return {
        actor,
        id:actor.id,
        name:actor.name,
        img:actor.img,
        level:s.level,
        className:s.details?.class || "Unassigned",
        magic:s.magic?.primary || "Unassigned",
        guild:s.details?.guild || "—",
        rank:s.details?.rank || "—",
        hp:s.resources.hp,
        hpPercent:percent(s.resources.hp.value,s.resources.hp.max),
        mana:s.resources.mana,
        manaPercent:percent(s.resources.mana.value,s.resources.mana.max),
        curse:s.resources.curse,
        cursePercent:percent(s.resources.curse.value,s.resources.curse.max),
        conditions,
        summons,
        slayerForm:Boolean(s.slayer?.formActive),
        pendingPaths:pendingMagicChoices(actor).length,
        owner:actor.isOwner
      };
    });
    return {rows,isGM:game.user.isGM,empty:rows.length===0};
  }

  _actor(target) { return game.actors.get(target.dataset.actorId); }
  static _openActor(event,target) { event.preventDefault(); this._actor(target)?.sheet?.render(true); }
  static _openBuilder(event,target) { event.preventDefault(); const a=this._actor(target); if (a) openCharacterBuilder(a); }
  static _openPaths(event,target) { event.preventDefault(); const a=this._actor(target); if (a) openMagicProgression(a); }
  static async _shortRest(event,target) { event.preventDefault(); const a=this._actor(target); if (a?.isOwner) { await a.shortRest(); this.render({force:true}); } }
  static async _longRest(event,target) { event.preventDefault(); const a=this._actor(target); if (a?.isOwner) { await a.longRest(); this.render({force:true}); } }
  static _refresh(event,target) { event.preventDefault(); this.render({force:true}); }
}

export function openPartyTracker() {
  const app=new PartyTracker();
  app.render({force:true});
  return app;
}

export function registerPartyTrackerHooks() {
  Hooks.on("renderActorDirectory",(app,html)=>{
    const root=html?.[0] ?? html;
    if (!root?.querySelector || root.querySelector(".ftr-open-party-tracker")) return;
    const header=root.querySelector(".directory-header .header-actions, .directory-header");
    if (!header) return;
    const button=document.createElement("button");
    button.type="button";
    button.className="ftr-open-party-tracker";
    button.innerHTML='<i class="fas fa-people-group"></i> Party Tracker';
    button.addEventListener("click",()=>openPartyTracker());
    header.append(button);
  });
}
