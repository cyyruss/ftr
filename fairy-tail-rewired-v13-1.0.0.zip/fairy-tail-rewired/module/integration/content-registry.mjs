import {SYSTEM_ID} from "../config.mjs";

const providers=new Map();

export function registerContentProvider(id,provider={}) {
  if (!id) throw new Error("A content provider id is required.");
  const normalized={id,label:provider.label ?? id,version:provider.version ?? "",getActors:provider.getActors,getItems:provider.getItems,openBrowser:provider.openBrowser};
  providers.set(id,normalized);
  Hooks.callAll("ftr.contentProviderRegistered",normalized);
  return normalized;
}
export function unregisterContentProvider(id) { const p=providers.get(id); providers.delete(id); if (p) Hooks.callAll("ftr.contentProviderUnregistered",p); return Boolean(p); }
export function listContentProviders(){ return [...providers.values()]; }
export async function providerActors(id){ const p=providers.get(id); return p?.getActors ? await p.getActors() : []; }
export async function providerItems(id){ const p=providers.get(id); return p?.getItems ? await p.getItems() : []; }
export async function importActorData(data,{folder=null,renderSheet=false}={}) {
  if (!game.user.isGM) throw new Error("Only a GM can import bestiary Actors.");
  const source=foundry.utils.deepClone(data);
  source.folder=folder?.id ?? folder ?? null;
  source.flags ??={}; source.flags[SYSTEM_ID] ??={}; source.flags[SYSTEM_ID].contentImported=true;
  const actor=await Actor.create(source,{renderSheet});
  Hooks.callAll("ftr.contentImported",{document:actor,kind:"Actor"});
  return actor;
}
export async function importItemData(data,{folder=null,actor=null}={}) {
  const source=foundry.utils.deepClone(data);
  source.flags ??={}; source.flags[SYSTEM_ID] ??={}; source.flags[SYSTEM_ID].contentImported=true;
  if (actor) { const [item]=await actor.createEmbeddedDocuments("Item",[source]); Hooks.callAll("ftr.contentImported",{document:item,kind:"Item"}); return item; }
  if (!game.user.isGM) throw new Error("Only a GM can import world Items.");
  source.folder=folder?.id ?? folder ?? null;
  const item=await Item.create(source);
  Hooks.callAll("ftr.contentImported",{document:item,kind:"Item"});
  return item;
}
export function openContentProvider(id){ const p=providers.get(id); if (!p?.openBrowser) return ui.notifications.warn(`Content provider ${id} has no browser.`); return p.openBrowser(); }
