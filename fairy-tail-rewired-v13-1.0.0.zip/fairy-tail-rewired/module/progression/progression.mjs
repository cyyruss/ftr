import {SYSTEM_ID} from "../config.mjs";

function progressionFlag(magic) {
  return magic?.getFlag?.(SYSTEM_ID,"progression") ?? magic?.flags?.[SYSTEM_ID]?.progression ?? null;
}

function choiceFlag(item) {
  return item?.getFlag?.(SYSTEM_ID,"progressionChoice") ?? item?.flags?.[SYSTEM_ID]?.progressionChoice ?? null;
}

export function slugifyMagic(name="") {
  return String(name).toLowerCase().normalize("NFKD").replace(/[^a-z0-9]+/g,"-").replace(/^-|-$/g,"");
}

export function actorMagicItems(actor) {
  return actor?.items?.filter?.(i=>i.type === "magic" && progressionFlag(i)?.milestones?.length) ?? [];
}

export function getMagicProgression(magic) {
  return progressionFlag(magic) ?? {source:magic?.system?.loreTag ?? "rewired", milestones:[]};
}

export function takenMagicChoices(actor, magic) {
  const key=slugifyMagic(magic?.name);
  const out=new Map();
  for (const item of actor?.items ?? []) {
    const flag=choiceFlag(item);
    if (!flag || flag.magicKey !== key) continue;
    out.set(flag.milestoneId,{item,flag});
  }
  return out;
}

export function progressionStatus(actor, magic) {
  const level=Number(actor?.system?.level||1);
  const progression=getMagicProgression(magic);
  const taken=takenMagicChoices(actor,magic);
  const takenChoiceIds=new Set([...taken.values()].map(x=>x.flag.choiceId));
  const milestones=(progression.milestones ?? []).map(m=>{
    const selected=taken.get(m.id) ?? null;
    const choices=(m.choices ?? []).map(c=>{
      const requiredLevel=Number(c.level ?? m.level ?? 1);
      const missing=(c.requires ?? []).filter(req=>!takenChoiceIds.has(req));
      const levelReady=level >= requiredLevel;
      const available=levelReady && missing.length===0;
      const lockedReason=!levelReady ? `Requires level ${requiredLevel}` : missing.length ? `Requires earlier path: ${missing.join(", ")}` : "";
      return {...c,available,lockedReason};
    });
    const eligible=choices.some(c=>c.available);
    return {...m,choices,selected,eligible,pending:eligible && !selected};
  });
  return {magic,progression,milestones,pending:milestones.filter(m=>m.pending),taken};
}

export function pendingMagicChoices(actor) {
  return actorMagicItems(actor).flatMap(magic=>progressionStatus(actor,magic).pending.map(m=>({magic,milestone:m})));
}

function effectMode(mode="ADD") {
  const modes=CONST.ACTIVE_EFFECT_MODES;
  return modes[String(mode).toUpperCase()] ?? modes.ADD;
}

async function createChoiceEffect(actor, magic, milestone, choice, feature) {
  const changes=(choice.changes ?? []).map((c,index)=>({
    key:c.key,
    mode:effectMode(c.mode),
    value:String(c.value),
    priority:Number(c.priority ?? 20+index)
  })).filter(c=>c.key);
  if (!changes.length) return null;
  const [effect]=await actor.createEmbeddedDocuments("ActiveEffect",[{
    name:`${magic.name}: ${choice.name}`,
    img:feature?.img ?? magic.img,
    origin:feature?.uuid ?? magic.uuid,
    disabled:false,
    changes,
    flags:{[SYSTEM_ID]:{
      progressionEffect:true,
      featureId:feature?.id ?? "",
      magicKey:slugifyMagic(magic.name),
      milestoneId:milestone.id,
      choiceId:choice.id
    }}
  }]);
  return effect ?? null;
}

export async function applyMagicChoice(actor, magic, milestoneId, choiceId) {
  if (!actor?.isOwner) throw new Error("You do not have permission to advance this Actor.");
  const status=progressionStatus(actor,magic);
  const milestone=status.milestones.find(m=>m.id===milestoneId);
  if (!milestone) throw new Error("Magic progression milestone not found.");
  if (milestone.selected) throw new Error(`${milestone.label} already has a selected path feature.`);
  const choice=milestone.choices.find(c=>c.id===choiceId);
  if (!choice) throw new Error("Magic progression choice not found.");
  if (!choice.available) throw new Error(choice.lockedReason || "That choice is not available at this level.");
  for (const req of (choice.requires ?? [])) {
    const has=[...status.taken.values()].some(x=>x.flag.choiceId===req);
    if (!has) throw new Error(`${choice.name} requires an earlier path choice.`);
  }

  const flags={
    [SYSTEM_ID]:{
      progressionChoice:{
        magicKey:slugifyMagic(magic.name),
        magicName:magic.name,
        magicSourceUuid:magic.getFlag?.(SYSTEM_ID,"sourceUuid") ?? magic.uuid,
        milestoneId:milestone.id,
        choiceId:choice.id,
        level:Number(choice.level ?? milestone.level ?? actor.system.level),
        source:status.progression.source ?? magic.system.loreTag ?? "rewired"
      }
    }
  };
  const featureData={
    name:choice.name,
    type:"feature",
    img:choice.img || magic.img || "icons/svg/upgrade.svg",
    system:{
      description:choice.description || choice.summary || `<p>${choice.name} is a ${magic.name} path feature.</p>`,
      source:choice.source || magic.system.source || "",
      loreTag:status.progression.source ?? magic.system.loreTag ?? "rewired",
      level:Number(choice.level ?? milestone.level ?? 0),
      magicSchool:magic.name,
      actionType:"utility"
    },
    flags
  };
  const [feature]=await actor.createEmbeddedDocuments("Item",[featureData]);
  let effect=null;
  try { effect=await createChoiceEffect(actor,magic,milestone,choice,feature); }
  catch (err) { console.error(`${SYSTEM_ID} | Failed to create progression effect`,err); }
  if (actor.recordAdvancement) await actor.recordAdvancement({
    type:"magic-path",
    summary:`${magic.name}: ${choice.name}`,
    data:{milestoneId,choiceId,featureId:feature?.id ?? "",effectId:effect?.id ?? ""}
  });
  Hooks.callAll("ftr.magicPathChosen",actor,magic,milestone,choice,feature,effect);
  return {feature,effect,milestone,choice};
}

export async function removeMagicChoice(actor, feature) {
  const flag=choiceFlag(feature);
  if (!flag) return false;
  const effects=actor.effects.filter(e=>{
    const f=e.getFlag?.(SYSTEM_ID,"progressionEffect");
    return f && e.getFlag(SYSTEM_ID,"featureId")===feature.id;
  });
  if (effects.length) await actor.deleteEmbeddedDocuments("ActiveEffect",effects.map(e=>e.id));
  await actor.deleteEmbeddedDocuments("Item",[feature.id]);
  if (actor.recordAdvancement) await actor.recordAdvancement({type:"magic-path-respec",summary:`Removed ${feature.name}`,data:flag});
  Hooks.callAll("ftr.magicPathRemoved",actor,feature,flag);
  return true;
}
