import {FTR, SYSTEM_ID, signed} from "../config.mjs";
import {dismissSummon} from "../automation/summoning.mjs";
import {openCharacterBuilder} from "../apps/character-builder.mjs";
import {openPartyTracker} from "../apps/party-tracker.mjs";
import {openMagicProgression} from "../apps/progression-app.mjs";
import {pendingMagicChoices, progressionStatus} from "../progression/progression.mjs";

export class FTRActorSheet extends foundry.appv1.sheets.ActorSheet {
  static get defaultOptions() {
    return foundry.utils.mergeObject(super.defaultOptions, {
      classes:["fairy-tail-rewired","sheet","actor"], width:920, height:820,
      tabs:[{navSelector:".sheet-tabs",contentSelector:".sheet-body",initial:"overview"}],
      dragDrop:[{dragSelector:".item-row",dropSelector:null}], submitOnChange:true, closeOnSubmit:false
    });
  }
  get template() { return `systems/${SYSTEM_ID}/templates/actor-sheet.hbs`; }

  _getHeaderButtons() {
    const buttons=super._getHeaderButtons();
    if (this.actor.type === "character" && this.actor.isOwner) {
      buttons.unshift({label:"Paths",class:"ftr-paths",icon:"fas fa-code-branch",onclick:()=>openMagicProgression(this.actor)});
      buttons.unshift({label:"Builder",class:"ftr-builder",icon:"fas fa-wand-sparkles",onclick:()=>openCharacterBuilder(this.actor)});
    }
    buttons.unshift({label:"Party",class:"ftr-party",icon:"fas fa-people-group",onclick:()=>openPartyTracker()});
    return buttons;
  }

  async getData(options={}) {
    const data=await super.getData(options);
    const s=this.actor.system;
    data.system=s;
    data.isCharacter=this.actor.type === "character";
    data.isNpc=this.actor.type === "npc";
    data.isSummon=this.actor.type === "summon";
    data.abilities=Object.entries(s.abilities).map(([key,v])=>({key,label:FTR.abilities[key],...v,modSigned:signed(v.mod)}));
    data.skills=Object.entries(s.skills).map(([key,v])=>({key,label:FTR.skills[key]?.label??key,ability:v.ability.toUpperCase(),...v,totalSigned:signed(v.total)}));
    data.itemsByType={};
    for (const item of this.actor.items) (data.itemsByType[item.type] ??= []).push(item);
    data.magicItems=[...this.actor.items].filter(i=>["spell","technique","magic","celestialKey","transformation"].includes(i.type));
    data.combatItems=[...this.actor.items].filter(i=>["weapon","armor","equipment","consumable"].includes(i.type));
    data.featureItems=[...this.actor.items].filter(i=>["feature","feat","class","race","background"].includes(i.type));
    data.effects=[...this.actor.effects];
    data.conditions=Object.entries(FTR.conditions).filter(([k])=>k in s.conditions).map(([key,cfg])=>({key,label:cfg.label,rank:Number(s.conditions[key]||0),active:Number(s.conditions[key]||0)>0}));
    data.activeSummons=game.actors?.filter(a=>a.type==="summon" && a.getFlag(SYSTEM_ID,"summonerUuid")===this.actor.uuid) ?? [];
    data.theme=game.settings.get(SYSTEM_ID,"sheetTheme");
    const className=s.details?.class || s.legacy?.className || "";
    data.classLogo=FTR.classLogos[className] ?? "";
    data.classLogoLabel=className || "Unassigned Class";
    data.magicProgressions=this.actor.type === "character" ? this.actor.items.filter(i=>i.type==="magic").map(m=>{ const st=progressionStatus(this.actor,m); return {id:m.id,name:m.name,pending:st.pending.length,total:st.milestones.length,chosen:st.milestones.filter(x=>x.selected).length}; }).filter(x=>x.total>0) : [];
    data.pendingMagicChoices=this.actor.type === "character" ? pendingMagicChoices(this.actor).length : 0;
    data.config=FTR;
    return data;
  }

  activateListeners(html) {
    super.activateListeners(html);
    if (!this.options.editable) return;
    const root=html[0] ?? html;
    root.querySelectorAll("[data-action]").forEach(el=>el.addEventListener("click",ev=>this._onAction(ev)));
    root.querySelectorAll(".item-row").forEach(el=>el.setAttribute("draggable","true"));
  }

  async _onAction(event) {
    event.preventDefault();
    const el=event.currentTarget;
    const action=el.dataset.action;
    const id=el.closest("[data-item-id]")?.dataset.itemId || el.dataset.itemId;
    if (action === "roll-ability") return this.actor.rollAbility(el.dataset.key,{mode:event.shiftKey?"advantage":"normal"});
    if (action === "roll-save") return this.actor.rollSave(el.dataset.key,{mode:event.shiftKey?"advantage":"normal"});
    if (action === "roll-skill") return this.actor.rollSkill(el.dataset.key,{mode:event.shiftKey?"advantage":"normal"});
    if (action === "use-item") return this.actor.items.get(id)?.use();
    if (action === "edit-item") return this.actor.items.get(id)?.sheet?.render(true);
    if (action === "delete-item") return this.actor.deleteEmbeddedDocuments("Item",[id]);
    if (action === "create-item") return this.actor.createEmbeddedDocuments("Item",[{name:`New ${el.dataset.type}`,type:el.dataset.type}]);
    if (action === "short-rest") return this.actor.shortRest();
    if (action === "long-rest") return this.actor.longRest();
    if (action === "recover-condition") return this.actor.recoverCondition(el.dataset.key);
    if (action === "slayer-devour") return this.actor.slayerDevour();
    if (action === "toggle-slayer-form") return this.actor.toggleSlayerForm();
    if (action === "magic-paths") return openMagicProgression(this.actor);
    if (action === "dismiss-summon") return dismissSummon(game.actors.get(el.dataset.actorId));
    if (action === "effect-delete") return this.actor.deleteEmbeddedDocuments("ActiveEffect",[el.dataset.effectId]);
    if (action === "effect-toggle") {
      const e=this.actor.effects.get(el.dataset.effectId); return e?.update({disabled:!e.disabled});
    }
  }
}

export class FTRNPCSheet extends FTRActorSheet {
  static get defaultOptions() { return foundry.utils.mergeObject(super.defaultOptions,{width:860,height:760}); }
}
