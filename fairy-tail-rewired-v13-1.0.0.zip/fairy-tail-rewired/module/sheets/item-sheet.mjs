import {FTR, SYSTEM_ID} from "../config.mjs";

const ACTION_TYPES = new Set(["spell","technique","weapon","consumable","celestialKey","transformation"]);

export class FTRItemSheet extends foundry.appv1.sheets.ItemSheet {
  static get defaultOptions() {
    return foundry.utils.mergeObject(super.defaultOptions, {
      classes:["fairy-tail-rewired","sheet","item","ftr-item-sheet"],
      width:820,
      height:790,
      tabs:[{navSelector:".sheet-tabs",contentSelector:".sheet-body",initial:"identity"}],
      submitOnChange:true,
      closeOnSubmit:false
    });
  }

  get template() { return `systems/${SYSTEM_ID}/templates/item-sheet.hbs`; }

  async getData(options={}) {
    const data=await super.getData(options);
    const s=this.item.system;
    data.system=s;
    data.config=FTR;
    data.isAction=ACTION_TYPES.has(this.item.type);
    data.isCelestial=this.item.type === "celestialKey";
    data.isTransformation=this.item.type === "transformation" || Boolean(s.transformation?.enabled);
    data.isWeapon=this.item.type === "weapon";
    data.isArmor=this.item.type === "armor";
    data.isClass=this.item.type === "class";
    data.isMagic=this.item.type === "magic";
    data.isRace=this.item.type === "race";
    data.isBackground=this.item.type === "background";
    data.isMarketItem=["weapon","armor","equipment","consumable","celestialKey","transformation"].includes(this.item.type);
    data.damageParts=s.damage?.parts ?? [];
    data.effects=[...this.item.effects];
    data.itemTypeLabel=this.item.type === "celestialKey" ? "Celestial Key" : this.item.type.replace(/([A-Z])/g," $1").replace(/^./,c=>c.toUpperCase());
    data.itemTypeIcon=FTR.itemTypeIcons[this.item.type] ?? "fa-sparkles";
    data.classLogo=this.item.type === "class" ? (FTR.classLogos[this.item.name] ?? "") : "";
    data.classInfo=this.item.type === "class" ? (FTR.classProgression[this.item.name] ?? null) : null;
    data.backgroundSkillLabels=(s.backgroundData?.skillChoices ?? []).map(k=>FTR.skills[k]?.label ?? k);
    data.resourceSummary=[];
    if (Number(s.cost?.mana||s.manaCost||0)>0) data.resourceSummary.push({label:"MP",value:Number(s.cost?.mana||s.manaCost||0),class:"mana"});
    if (Number(s.cost?.curse||s.curseCost||0)>0) data.resourceSummary.push({label:"Curse",value:Number(s.cost?.curse||s.curseCost||0),class:"curse"});
    if (Number(s.cost?.demonPoints||0)>0) data.resourceSummary.push({label:"DP",value:Number(s.cost?.demonPoints||0),class:"demon"});
    if (Number(s.uses?.max||0)>0) data.resourceSummary.push({label:"Uses",value:`${s.uses.value}/${s.uses.max}`,class:"uses"});
    return data;
  }

  activateListeners(html) {
    super.activateListeners(html);
    if (!this.options.editable) return;
    const root=html[0] ?? html;
    root.querySelectorAll("[data-action]").forEach(el=>el.addEventListener("click",ev=>this._onAction(ev)));
  }

  async _onAction(event) {
    event.preventDefault();
    const el=event.currentTarget;
    const action=el.dataset.action;
    if (action === "test-use") return this.item.use();
    if (action === "add-damage") {
      const parts=[...(this.item.system.damage?.parts??[])].map(p=>({formula:p.formula,type:p.type}));
      parts.push({formula:"1d6",type:"magic"});
      return this.item.update({"system.damage.parts":parts});
    }
    if (action === "remove-damage") {
      const idx=Number(el.dataset.index);
      const parts=[...(this.item.system.damage?.parts??[])];
      parts.splice(idx,1);
      return this.item.update({"system.damage.parts":parts.map(p=>({formula:p.formula,type:p.type}))});
    }
    if (action === "create-effect") {
      const created=await this.item.createEmbeddedDocuments("ActiveEffect",[{name:`${this.item.name} Effect`,img:this.item.img,transfer:true,disabled:false,changes:[]}]);
      return created?.[0]?.sheet?.render(true);
    }
    if (action === "edit-effect") return this.item.effects.get(el.dataset.effectId)?.sheet?.render(true);
    if (action === "toggle-effect") {
      const effect=this.item.effects.get(el.dataset.effectId);
      return effect?.update({disabled:!effect.disabled});
    }
    if (action === "delete-effect") return this.item.deleteEmbeddedDocuments("ActiveEffect",[el.dataset.effectId]);
  }
}
