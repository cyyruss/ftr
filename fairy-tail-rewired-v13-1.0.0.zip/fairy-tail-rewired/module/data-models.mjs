import {FTR, manaForClass, proficiencyForLevel, SCHEMA_VERSION} from "./config.mjs";

const f = foundry.data.fields;

function resourceField(value=0, max=0) {
  return new f.SchemaField({
    value: new f.NumberField({integer:true, min:0, initial:value}),
    max: new f.NumberField({integer:true, min:0, initial:max}),
    temp: new f.NumberField({integer:true, min:0, initial:0}),
    overrideMax: new f.NumberField({integer:true, min:0, initial:0})
  });
}
function abilityField() {
  return new f.SchemaField({
    value: new f.NumberField({integer:true, min:1, initial:10}),
    mod: new f.NumberField({integer:true, initial:0}),
    saveProficient: new f.BooleanField({initial:false}),
    saveBonus: new f.NumberField({integer:true, initial:0})
  });
}
function skillField(ability) {
  return new f.SchemaField({
    ability: new f.StringField({initial:ability}),
    rank: new f.NumberField({integer:true, min:0, max:2, initial:0}),
    bonus: new f.NumberField({integer:true, initial:0}),
    total: new f.NumberField({integer:true, initial:0})
  });
}
function stringArray() { return new f.ArrayField(new f.StringField({initial:""}), {initial:[]}); }

function commonActorSchema() {
  return {
    schemaVersion: new f.NumberField({integer:true, min:0, initial:SCHEMA_VERSION}),
    biography: new f.HTMLField({initial:""}),
    level: new f.NumberField({integer:true, min:1, max:30, initial:1}),
    experience: new f.NumberField({integer:true, min:0, initial:0}),
    details: new f.SchemaField({
      race: new f.StringField({initial:"Human"}),
      class: new f.StringField({initial:""}),
      background: new f.StringField({initial:""}),
      guild: new f.StringField({initial:""}),
      guildMark: new f.StringField({initial:""}),
      rank: new f.StringField({initial:""}),
      title: new f.StringField({initial:""}),
      cr: new f.StringField({initial:""}),
      threat: new f.NumberField({integer:true, min:0, initial:0}),
      source: new f.StringField({initial:""}),
      tags: stringArray(),
      loreTag: new f.StringField({initial:"rewired"})
    }),
    abilities: new f.SchemaField(Object.fromEntries(Object.keys(FTR.abilities).map(k => [k, abilityField()]))),
    skills: new f.SchemaField(Object.fromEntries(Object.entries(FTR.skills).map(([k,v]) => [k, skillField(v.ability)]))),
    proficiency: new f.NumberField({integer:true, min:0, initial:2}),
    resources: new f.SchemaField({
      hp: resourceField(10,10),
      mana: resourceField(0,0),
      curse: resourceField(0,0),
      demonPoints: resourceField(0,100),
      growth: resourceField(0,0),
      relation: resourceField(0,0)
    }),
    attributes: new f.SchemaField({
      ac: new f.SchemaField({
        value: new f.NumberField({integer:true, min:0, initial:10}),
        override: new f.NumberField({integer:true, min:0, initial:0}),
        bonus: new f.NumberField({integer:true, initial:0}),
        formula: new f.StringField({initial:"10 + @abilities.dex.mod"})
      }),
      initiative: new f.NumberField({integer:true, initial:0}),
      passivePerception: new f.NumberField({integer:true, initial:10}),
      exhaustion: new f.NumberField({integer:true, min:0, max:6, initial:0}),
      size: new f.StringField({initial:"medium"}),
      hitDie: new f.NumberField({integer:true, min:4, max:20, initial:8})
    }),
    movement: new f.SchemaField({
      walk: new f.NumberField({integer:true, min:0, initial:30}),
      fly: new f.NumberField({integer:true, min:0, initial:0}),
      swim: new f.NumberField({integer:true, min:0, initial:0}),
      climb: new f.NumberField({integer:true, min:0, initial:0}),
      burrow: new f.NumberField({integer:true, min:0, initial:0}),
      bonus: new f.NumberField({integer:true, initial:0}),
      effectiveWalk: new f.NumberField({integer:true, min:0, initial:30})
    }),
    magic: new f.SchemaField({
      primary: new f.StringField({initial:""}),
      secondary: new f.StringField({initial:""}),
      ability: new f.StringField({initial:"int"}),
      mod: new f.NumberField({integer:true, initial:0}),
      attack: new f.NumberField({integer:true, initial:2}),
      attackBonus: new f.NumberField({integer:true, initial:0}),
      dc: new f.NumberField({integer:true, min:0, initial:10}),
      dcBonus: new f.NumberField({integer:true, initial:0}),
      maxTechniqueLevel: new f.NumberField({integer:true, min:0, max:9, initial:3}),
      magicCircleReduction: new f.NumberField({integer:true, min:0, initial:0}),
      ultimateUnlocked: new f.BooleanField({initial:false}),
      ultimatePrimed: new f.BooleanField({initial:false}),
      limitBreak: new f.BooleanField({initial:false})
    }),
    defenses: new f.SchemaField({
      resistances: stringArray(), immunities: stringArray(), vulnerabilities: stringArray(),
      conditionImmunities: stringArray(), damageReduction: new f.NumberField({integer:true, min:0, initial:0})
    }),
    conditions: new f.SchemaField({
      silenced: new f.NumberField({integer:true, min:0, max:1, initial:0}),
      winded: new f.NumberField({integer:true, min:0, max:20, initial:0}),
      burned: new f.NumberField({integer:true, min:0, max:100, initial:0}),
      slowed: new f.NumberField({integer:true, min:0, max:1, initial:0}),
      celestia: new f.NumberField({integer:true, min:0, max:5, initial:0})
    }),
    slayer: new f.SchemaField({
      type: new f.StringField({initial:""}),
      generation: new f.NumberField({integer:true, min:0, initial:0}),
      element: new f.StringField({initial:""}),
      devourEnabled: new f.BooleanField({initial:false}),
      targetTag: new f.StringField({initial:""}),
      damageMultiplier: new f.NumberField({min:1, initial:2}),
      form: new f.StringField({initial:""}),
      formActive: new f.BooleanField({initial:false})
    }),
    summoning: new f.SchemaField({
      maxActive: new f.NumberField({integer:true, min:1, initial:1}),
      activeActorIds: stringArray(),
      contractBonus: new f.NumberField({integer:true, initial:0}),
      celestialMage: new f.BooleanField({initial:false}),
      starDressUnlocked: new f.BooleanField({initial:false})
    }),
    boss: new f.SchemaField({
      enabled: new f.BooleanField({initial:false}),
      phase: new f.NumberField({integer:true, min:1, initial:1}),
      maxPhase: new f.NumberField({integer:true, min:1, initial:1}),
      legendaryActions: resourceField(0,0),
      description: new f.StringField({initial:""})
    }),
    automation: new f.SchemaField({
      autoMana: new f.BooleanField({initial:true}),
      autoHp: new f.BooleanField({initial:false}),
      autoDamage: new f.BooleanField({initial:true}),
      autoConditions: new f.BooleanField({initial:true}),
      autoBurned: new f.BooleanField({initial:true})
    }),
    advancement: new f.SchemaField({
      history: new f.ArrayField(new f.SchemaField({
        timestamp: new f.NumberField({integer:true, min:0, initial:0}),
        type: new f.StringField({initial:"manual"}),
        summary: new f.StringField({initial:""}),
        data: new f.StringField({initial:""})
      }), {initial:[]})
    }),
    legacy: new f.SchemaField({
      race: new f.StringField({initial:""}), className: new f.StringField({initial:""}),
      magic: new f.StringField({initial:""}), ac: new f.NumberField({integer:true, initial:0}),
      speed: new f.NumberField({integer:true, initial:0})
    })
  };
}

export class CharacterData extends foundry.abstract.TypeDataModel {
  static defineSchema() { return commonActorSchema(); }
  prepareDerivedData() {
    const level = Number(this.level || 1);
    this.proficiency = proficiencyForLevel(level);
    for (const ability of Object.values(this.abilities)) ability.mod = Math.floor((Number(ability.value || 10) - 10) / 2);
    for (const skill of Object.values(this.skills)) {
      const a = this.abilities[skill.ability] ?? this.abilities.int;
      skill.total = Number(a.mod || 0) + Number(skill.rank || 0) * this.proficiency + Number(skill.bonus || 0);
    }
    const magicKey = Object.hasOwn(this.abilities, this.magic.ability) ? this.magic.ability : "int";
    const magicMod = this.abilities[magicKey].mod;
    this.magic.mod = magicMod;
    this.magic.attack = this.proficiency + magicMod + Number(this.magic.attackBonus || 0);
    this.magic.dc = 8 + this.proficiency + magicMod + Number(this.magic.dcBonus || 0);
    this.magic.ultimateUnlocked = Number(this.abilities[magicKey].value || 0) >= 20 || Boolean(this.magic.ultimateUnlocked);

    const cls = this.details.class || this.legacy.className || "";
    const classInfo = FTR.classProgression[cls];
    if (classInfo) this.attributes.hitDie = classInfo.hitDie;
    if (this.automation.autoMana) {
      let calculated = Math.max(0, manaForClass(cls, level, magicMod, this.proficiency));
      const race = this.details.race || this.legacy.race || "";
      if (/^human$/i.test(race)) calculated += 2 + (level >= 8 ? 2 : 0) + (level >= 16 ? 2 : 0);
      if (/^exceed$/i.test(race) && calculated > level) calculated = Math.max(level, calculated - level);
      this.resources.mana.max = this.resources.mana.overrideMax > 0 ? this.resources.mana.overrideMax : calculated;
      this.resources.mana.value = Math.min(this.resources.mana.value, this.resources.mana.max);
    }
    if (this.resources.curse.overrideMax > 0) this.resources.curse.max = this.resources.curse.overrideMax;
    if (this.automation.autoHp && this.resources.hp.overrideMax <= 0 && classInfo) {
      const avg = Math.floor(classInfo.hitDie / 2) + 1;
      this.resources.hp.max = Math.max(1, classInfo.hitDie + this.abilities.con.mod + Math.max(0, level-1) * (avg + this.abilities.con.mod));
      this.resources.hp.value = Math.min(this.resources.hp.value, this.resources.hp.max);
    } else if (this.resources.hp.overrideMax > 0) this.resources.hp.max = this.resources.hp.overrideMax;

    const acOverride = Number(this.attributes.ac.override || this.legacy.ac || 0);
    let ac = acOverride || (10 + this.abilities.dex.mod);
    if ((cls === "Cauldron" || cls === "Warrior") && !acOverride) ac = 10 + this.abilities.dex.mod + this.abilities.con.mod;
    this.attributes.ac.value = Math.max(0, ac + Number(this.attributes.ac.bonus || 0));

    let speed = Number(this.movement.walk || this.legacy.speed || 30) + Number(this.movement.bonus || 0);
    speed -= Number(this.conditions.winded || 0) * 10;
    const celestia = Number(this.conditions.celestia || 0);
    if (celestia >= 2) speed -= (celestia - 1) * 10;
    this.movement.effectiveWalk = Math.max(0, speed);

    const perc = this.skills.perception;
    this.attributes.passivePerception = 10 + Number(perc?.total || 0);
  }
}
export class NPCData extends CharacterData {}
export class SummonData extends CharacterData {}

function damagePartField() {
  return new f.SchemaField({formula:new f.StringField({initial:""}), type:new f.StringField({initial:"magic"})});
}
function baseItemSchema() {
  return {
    schemaVersion: new f.NumberField({integer:true, min:0, initial:SCHEMA_VERSION}),
    description: new f.HTMLField({initial:""}),
    source: new f.StringField({initial:""}),
    loreTag: new f.StringField({initial:"rewired"}),
    level: new f.NumberField({integer:true, min:0, max:20, initial:0}),
    magicSchool: new f.StringField({initial:""}),
    activation: new f.SchemaField({
      type: new f.StringField({initial:"action"}), cost: new f.NumberField({min:0, initial:1}),
      reactionTrigger: new f.StringField({initial:""})
    }),
    cost: new f.SchemaField({
      mana: new f.NumberField({integer:true, min:0, initial:0}),
      curse: new f.NumberField({integer:true, min:0, initial:0}),
      demonPoints: new f.NumberField({integer:true, min:0, initial:0})
    }),
    manaCost: new f.NumberField({integer:true, min:0, initial:0}),
    curseCost: new f.NumberField({integer:true, min:0, initial:0}),
    range: new f.SchemaField({value:new f.NumberField({min:0, initial:0}), units:new f.StringField({initial:"ft"}), text:new f.StringField({initial:""})}),
    target: new f.SchemaField({value:new f.NumberField({integer:true, min:0, initial:1}), type:new f.StringField({initial:"creature"}), area:new f.StringField({initial:""})}),
    duration: new f.SchemaField({value:new f.NumberField({min:0, initial:0}), units:new f.StringField({initial:"instant"}), concentration:new f.BooleanField({initial:false}), text:new f.StringField({initial:""})}),
    components: new f.SchemaField({
      verbal:new f.BooleanField({initial:false}), somatic:new f.BooleanField({initial:false}), material:new f.BooleanField({initial:false}),
      materialText:new f.StringField({initial:""}), sound:new f.BooleanField({initial:false})
    }),
    actionType: new f.StringField({initial:"utility"}),
    ability: new f.StringField({initial:"magic"}),
    attackBonus: new f.NumberField({integer:true, initial:0}),
    save: new f.SchemaField({ability:new f.StringField({initial:""}), dc:new f.NumberField({integer:true, min:0, initial:0}), onSuccess:new f.StringField({initial:"half"})}),
    damage: new f.SchemaField({parts:new f.ArrayField(damagePartField(), {initial:[]}), versatile:new f.StringField({initial:""}), healing:new f.BooleanField({initial:false})}),
    uses: new f.SchemaField({value:new f.NumberField({integer:true, min:0, initial:0}), max:new f.NumberField({integer:true, min:0, initial:0}), per:new f.StringField({initial:""})}),
    upcast: new f.SchemaField({enabled:new f.BooleanField({initial:false}), maxLevel:new f.NumberField({integer:true, min:0, max:9, initial:0}), damagePerLevel:new f.StringField({initial:""}), manaPerLevel:new f.NumberField({integer:true, min:0, initial:1})}),
    automation: new f.SchemaField({
      condition:new f.StringField({initial:""}), conditionRank:new f.NumberField({integer:true, min:0, initial:0}), conditionOn:new f.StringField({initial:"failedSave"}),
      conditionDuration:new f.NumberField({integer:true, min:0, initial:0}), resourceRestore:new f.StringField({initial:""}), notes:new f.StringField({initial:""})
    }),
    armor: new f.SchemaField({ac:new f.NumberField({integer:true, min:0, initial:0}), dexCap:new f.NumberField({integer:true, initial:99}), equipped:new f.BooleanField({initial:false})}),
    weapon: new f.SchemaField({equipped:new f.BooleanField({initial:false}), proficient:new f.BooleanField({initial:true}), properties:stringArray()}),
    market: new f.SchemaField({
      rarity:new f.StringField({initial:"common"}),
      price:new f.NumberField({min:0, initial:0}),
      currency:new f.StringField({initial:"J"}),
      availability:new f.StringField({initial:"shop"}),
      quantity:new f.NumberField({integer:true,min:0,initial:1}),
      weight:new f.NumberField({min:0,initial:0}),
      restricted:new f.BooleanField({initial:false}),
      attunement:new f.BooleanField({initial:false})
    }),
    classData: new f.SchemaField({hitDie:new f.NumberField({integer:true, min:0, initial:0}), manaRule:new f.StringField({initial:""}), saveProficiencies:stringArray()}),
    backgroundData: new f.SchemaField({
      skillChoices:stringArray(),
      skillCount:new f.NumberField({integer:true,min:0,max:6,initial:0}),
      tools:stringArray(),
      languages:new f.StringField({initial:""}),
      startingCash:new f.NumberField({integer:true,min:0,initial:0}),
      featureName:new f.StringField({initial:""}),
      featGuidance:new f.StringField({initial:""})
    }),
    summon: new f.SchemaField({actorUuid:new f.StringField({initial:""}), keyRank:new f.StringField({initial:""}), summonCost:new f.NumberField({integer:true, min:0, initial:0}), maintainCost:new f.NumberField({integer:true, min:0, initial:0}), contractRequired:new f.BooleanField({initial:true})}),
    celestial: new f.SchemaField({gate:new f.StringField({initial:""}), keyRank:new f.StringField({initial:""}), spiritName:new f.StringField({initial:""}), contract:new f.BooleanField({initial:true}), starDress:new f.BooleanField({initial:false})}),
    transformation: new f.SchemaField({
      enabled:new f.BooleanField({initial:false}), name:new f.StringField({initial:""}), manaCost:new f.NumberField({integer:true, min:0, initial:0}),
      acBonus:new f.NumberField({integer:true, initial:0}), speedBonus:new f.NumberField({integer:true, initial:0}),
      magicAttackBonus:new f.NumberField({integer:true, initial:0}), magicDcBonus:new f.NumberField({integer:true, initial:0}),
      resistance:new f.StringField({initial:""}), durationRounds:new f.NumberField({integer:true, min:0, initial:10})
    })
  };
}
export class FTRItemData extends foundry.abstract.TypeDataModel { static defineSchema() { return baseItemSchema(); } }
