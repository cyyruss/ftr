/**
 * Lightweight staged action workflow for module interoperability.
 * Pre-stages use Hooks.call and are cancellable by returning false synchronously.
 * Post-stages use Hooks.callAll. Foundry hooks are not awaited.
 */
export class FTRWorkflow {
  constructor({actor,item,options={}}={}) {
    this.actor=actor;
    this.item=item;
    this.options=options;
    this.castLevel=Number(item?.system?.level||0);
    this.costs={mana:0,curse:0,demonPoints:0};
    this.targets=Array.from(game.user?.targets ?? []);
    this.attackRoll=null;
    this.damage=[];
    this.message=null;
    this.summon=null;
    this.result=null;
    this.cancelled=false;
    this.stage="created";
  }

  pre(stage,extra={}) {
    this.stage=stage;
    Object.assign(this,extra);
    const allowed=Hooks.call(`ftr.workflow.${stage}`,this);
    if (allowed === false) this.cancelled=true;
    return !this.cancelled;
  }

  post(stage,extra={}) {
    this.stage=stage;
    Object.assign(this,extra);
    Hooks.callAll(`ftr.workflow.${stage}`,this);
    return this;
  }

  complete(extra={}) {
    this.stage="complete";
    Object.assign(this,extra);
    Hooks.callAll("ftr.workflow.complete",this);
    return this.result;
  }
}
