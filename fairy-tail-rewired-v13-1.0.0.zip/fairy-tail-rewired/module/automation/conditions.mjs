import {FTR, SYSTEM_ID} from "../config.mjs";

export function installStatusEffects() {
  const existing = new Set((CONFIG.statusEffects ?? []).map(e => e.id));
  for (const [key, cfg] of Object.entries(FTR.conditions)) {
    const id = `ftr-${key}`;
    if (existing.has(id)) continue;
    CONFIG.statusEffects.push({id, name:cfg.label, img:cfg.icon});
  }
}

export async function setRankedCondition(actor, key, rank=1, {dc=0, sourceUuid="", additive=false}={}) {
  if (!actor || !(key in (actor.system.conditions ?? {}))) return null;
  const immunity = (actor.system.defenses?.conditionImmunities ?? []).map(String).map(s=>s.toLowerCase());
  if (immunity.includes(key.toLowerCase())) return null;
  const current = Number(actor.system.conditions[key] || 0);
  let next = additive ? current + Number(rank||0) : Number(rank||0);
  if (key === "celestia") next = Math.min(5, next);
  if (["silenced","slowed"].includes(key)) next = next > 0 ? 1 : 0;
  next = Math.max(0, next);
  await actor.update({[`system.conditions.${key}`]:next});
  if (next > 0) await ensureStatusEffect(actor, key, {dc, sourceUuid});
  else await removeStatusEffect(actor, key);
  Hooks.callAll("ftr.conditionChanged", actor, key, current, next);
  return next;
}

export async function ensureStatusEffect(actor, key, {dc=0, sourceUuid=""}={}) {
  const statusId = `ftr-${key}`;
  const found = actor.effects.find(e => e.statuses?.has?.(statusId) || e.getFlag(SYSTEM_ID,"condition") === key);
  if (found) {
    if (dc) await found.setFlag(SYSTEM_ID,"saveDc",Number(dc));
    return found;
  }
  const cfg = FTR.conditions[key];
  if (!cfg) return null;
  const [effect] = await actor.createEmbeddedDocuments("ActiveEffect", [{
    name: cfg.label,
    img: cfg.icon,
    statuses: [statusId],
    duration: {},
    flags: {[SYSTEM_ID]:{condition:key, saveDc:Number(dc||0), sourceUuid}}
  }]);
  return effect;
}

export async function removeStatusEffect(actor, key) {
  const statusId = `ftr-${key}`;
  const ids = actor.effects.filter(e => e.statuses?.has?.(statusId) || e.getFlag(SYSTEM_ID,"condition") === key).map(e=>e.id);
  if (ids.length) await actor.deleteEmbeddedDocuments("ActiveEffect", ids);
}

export async function clearCondition(actor, key) { return setRankedCondition(actor,key,0); }

export async function processTurnStart(actor) {
  if (!actor) return;
  const winded = Number(actor.system.conditions?.winded||0);
  if (winded > 0) {
    const roll = await new Roll(`${winded}d4`).evaluate();
    const dealt = await actor.applyDamage(roll.total, "slashing", {source:"Winded"});
    await roll.toMessage({speaker:ChatMessage.getSpeaker({actor}), flavor:`<strong>Winded</strong> start-of-turn damage (${dealt} after defenses)`});
  }
  Hooks.callAll("ftr.turnStart", actor);
}

export async function processTurnEnd(actor) {
  if (!actor) return;
  const burned = Number(actor.system.conditions?.burned||0);
  if (burned > 0) {
    const roll = await new Roll(`${burned}d4`).evaluate();
    const dealt = await actor.applyDamage(roll.total, "fire", {source:"Burned"});
    await roll.toMessage({speaker:ChatMessage.getSpeaker({actor}), flavor:`<strong>Burned</strong> end-of-turn damage (${dealt} after defenses)`});
  }
  if (Number(actor.system.conditions?.slowed||0) > 0) await clearCondition(actor,"slowed");
  Hooks.callAll("ftr.turnEnd", actor);
}

export async function attemptConditionRecovery(actor, key) {
  const rank = Number(actor.system.conditions?.[key]||0);
  if (!rank) return null;
  if (key === "burned") {
    const con = actor.system.abilities.con.mod;
    const roll = await actor.rollSave("con", {dc:10+rank, label:"Extinguish Burned"});
    if (roll?.total >= 10+rank) await setRankedCondition(actor,key,Math.max(0,rank-Math.max(1,con)));
    return roll;
  }
  const effect = actor.effects.find(e => e.getFlag(SYSTEM_ID,"condition") === key);
  const dc = Number(effect?.getFlag(SYSTEM_ID,"saveDc")||10);
  const ability = key === "celestia" ? (rank >= 4 ? "con" : "str") : "con";
  const roll = await actor.rollSave(ability,{dc,label:`Recover from ${FTR.conditions[key]?.label ?? key}`});
  if (roll?.total >= dc) await clearCondition(actor,key);
  return roll;
}
