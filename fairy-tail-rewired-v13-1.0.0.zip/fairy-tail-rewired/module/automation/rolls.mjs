import {FTR, signed} from "../config.mjs";

export function rollModeFormula(mode="normal") {
  if (mode === "advantage") return "2d20kh";
  if (mode === "disadvantage") return "2d20kl";
  return "1d20";
}

export async function d20Roll({actor, label, bonus=0, mode="normal", flavor="", options={}}={}) {
  const context = {actor, label, bonus:Number(bonus||0), mode, flavor, options};
  if (Hooks.call("ftr.preRoll", context) === false) return null;
  const formula = `${rollModeFormula(context.mode)} ${context.bonus >= 0 ? "+" : "-"} ${Math.abs(context.bonus)}`;
  const roll = await new Roll(formula, actor?.getRollData?.() ?? {}).evaluate();
  await roll.toMessage({
    speaker: actor ? ChatMessage.getSpeaker({actor}) : undefined,
    flavor: flavor || `<strong>${foundry.utils.escapeHTML(label || "Roll")}</strong>`
  }, options);
  Hooks.callAll("ftr.roll", roll, context);
  return roll;
}

export function getAbilityRollMode(actor, ability, kind="check", requested="normal") {
  let advantage = requested === "advantage";
  let disadvantage = requested === "disadvantage";
  const c = actor?.system?.conditions ?? {};
  if (ability === "str" && Number(c.celestia||0) >= 1) disadvantage = true;
  if (kind === "save" && ["str","dex"].includes(ability) && Number(c.winded||0) >= 3) disadvantage = true;
  if (kind === "save" && ability === "con" && Number(c.celestia||0) >= 4) disadvantage = true;
  if (advantage && disadvantage) return "normal";
  if (advantage) return "advantage";
  if (disadvantage) return "disadvantage";
  return "normal";
}

export async function abilityRoll(actor, ability, {mode="normal"}={}) {
  const data = actor.system.abilities?.[ability];
  if (!data) return null;
  mode = getAbilityRollMode(actor, ability, "check", mode);
  return d20Roll({actor, label:`${FTR.abilities[ability] ?? ability} Check`, bonus:data.mod, mode});
}

export async function saveRoll(actor, ability, {mode="normal", dc=null, label=null}={}) {
  const data = actor.system.abilities?.[ability];
  if (!data) return null;
  let bonus = Number(data.mod||0) + Number(data.saveBonus||0);
  if (data.saveProficient) bonus += Number(actor.system.proficiency||0);
  mode = getAbilityRollMode(actor, ability, "save", mode);
  const roll = await d20Roll({actor, label:label || `${FTR.abilities[ability] ?? ability} Save`, bonus, mode});
  if (roll && Number.isFinite(Number(dc))) {
    const success = roll.total >= Number(dc);
    Hooks.callAll("ftr.saveResolved", {actor, ability, dc:Number(dc), roll, success});
  }
  return roll;
}

export async function skillRoll(actor, skill, {mode="normal"}={}) {
  const data = actor.system.skills?.[skill];
  if (!data) return null;
  mode = getAbilityRollMode(actor, data.ability, "check", mode);
  return d20Roll({actor, label:`${FTR.skills[skill]?.label ?? skill} Check`, bonus:data.total, mode});
}

export async function damageRoll(actor, formula, {label="Damage", type="magic", speaker=true}={}) {
  if (!formula) return null;
  const roll = await new Roll(formula, actor?.getRollData?.() ?? {}).evaluate();
  if (speaker) await roll.toMessage({speaker:ChatMessage.getSpeaker({actor}), flavor:`<strong>${foundry.utils.escapeHTML(label)}</strong> <span class="ftr-damage-type">${foundry.utils.escapeHTML(type)}</span>`});
  Hooks.callAll("ftr.damageRoll", roll, {actor, formula, label, type});
  return roll;
}

export function describeBonus(n) { return signed(n); }
