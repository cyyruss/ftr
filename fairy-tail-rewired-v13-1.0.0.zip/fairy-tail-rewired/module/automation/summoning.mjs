import {SYSTEM_ID} from "../config.mjs";

async function getSourceActor(uuid) {
  if (!uuid) return null;
  try { return await fromUuid(uuid); } catch (_) { return null; }
}

function tokenPositionNearCaster(caster) {
  const token = caster.getActiveTokens?.()[0];
  if (!token) return {x:0,y:0};
  const grid = canvas.grid?.size ?? 100;
  return {x:token.document.x + grid, y:token.document.y};
}

function applySummonScaling(data, source, caster) {
  const scaling = source.getFlag?.(SYSTEM_ID,"summonScaling") ?? source.flags?.[SYSTEM_ID]?.summonScaling;
  if (!scaling || !data.system) return data;
  const level = Math.max(1, Number(caster.system.level||1));
  const scaleLevel = Math.max(1, Math.min(level, Number(scaling.levelCap||30)));
  data.system.level = scaleLevel;
  if (scaling.hpBase != null) {
    const max = Math.max(1, Number(scaling.hpBase||0) + Number(scaling.hpPerLevel||0) * scaleLevel);
    data.system.resources.hp.value=max; data.system.resources.hp.max=max; data.system.resources.hp.overrideMax=max;
  }
  if (scaling.manaBase != null) {
    const max = Math.max(0, Number(scaling.manaBase||0) + Number(scaling.manaPerLevel||0) * scaleLevel);
    data.system.resources.mana.value=max; data.system.resources.mana.max=max; data.system.resources.mana.overrideMax=max;
  }
  if (scaling.acBase != null) data.system.attributes.ac.override = Number(scaling.acBase||10) + Math.floor((scaleLevel-1)/Number(scaling.acEvery||5));
  if (scaling.abilityStep && scaleLevel > 1) {
    const steps=Math.floor((scaleLevel-1)/Number(scaling.abilityEvery||5));
    const key=String(scaling.ability||data.system.magic?.ability||"cha");
    if (data.system.abilities?.[key]) data.system.abilities[key].value=Math.min(30,Number(data.system.abilities[key].value||10)+steps*Number(scaling.abilityStep));
  }
  return data;
}

async function trackSummon(caster, summon, add=true) {
  const ids=Array.from(caster.system.summoning?.activeActorIds??[]).filter(id=>game.actors.has(id));
  const next=add ? Array.from(new Set([...ids,summon.id])) : ids.filter(id=>id!==summon.id);
  if (ids.length===next.length && ids.every((id,index)=>id===next[index])) return;
  await caster.update({"system.summoning.activeActorIds":next});
}

export async function validateSummon(caster,item) {
  if (!caster || !item) return {valid:false,message:"A caster and summon item are required."};
  const active=game.actors.filter(a=>a.type === "summon" && a.getFlag(SYSTEM_ID,"summonerUuid") === caster.uuid);
  const maxActive=Math.max(1,Number(caster.system.summoning?.maxActive||1)+Number(caster.system.summoning?.contractBonus||0));
  if (active.length >= maxActive) return {valid:false,message:`${caster.name} already has the maximum number of active summons (${maxActive}).`,active,maxActive};
  const source=await getSourceActor(item.system.summon?.actorUuid);
  if (!source) return {valid:false,message:`No summon Actor is linked to ${item.name}. Import/link a summon first.`,active,maxActive};
  if (item.system.summon?.contractRequired && item.type === "celestialKey" && !item.system.celestial?.contract) return {valid:false,message:`${item.name} does not have an active Celestial Spirit contract.`,active,maxActive,source};
  return {valid:true,active,maxActive,source};
}

export async function summonFromItem(caster, item, {position=null}={}) {
  if (!caster || !item) return null;
  const validation=await validateSummon(caster,item);
  if (!validation.valid) { ui.notifications.warn(validation.message); return null; }
  const source=validation.source;
  const data = applySummonScaling(source.toObject(), source, caster);
  delete data._id;
  data.type = "summon";
  data.name = `${source.name} — ${caster.name}`;
  data.ownership = foundry.utils.deepClone(caster.ownership);
  data.flags ??= {};
  data.flags[SYSTEM_ID] = {
    ...(data.flags[SYSTEM_ID]??{}),
    summonerUuid:caster.uuid,
    sourceActorUuid:source.uuid,
    sourceItemUuid:item.uuid,
    maintainCost:Number(item.system.summon?.maintainCost||0),
    ephemeral:true,
    summonedAtLevel:Number(caster.system.level||1)
  };
  const summoned = await Actor.implementation.create(data,{renderSheet:false});
  if (!summoned) return null;
  await trackSummon(caster,summoned,true);
  if (canvas?.ready) {
    const p = position ?? tokenPositionNearCaster(caster);
    const tokenData = await summoned.getTokenDocument({x:p.x,y:p.y,actorLink:true});
    await canvas.scene.createEmbeddedDocuments("Token",[tokenData.toObject()]);
  }
  Hooks.callAll("ftr.summoned", caster, summoned, item);
  return summoned;
}

export async function dismissSummon(summon, {reason="Dismissed"}={}) {
  if (!summon || summon.type !== "summon") return false;
  const tokens = summon.getActiveTokens?.(true) ?? [];
  for (const token of tokens) if (token.document?.parent) await token.document.delete();
  const casterUuid = summon.getFlag(SYSTEM_ID,"summonerUuid");
  let caster=null;
  try { caster=casterUuid ? await fromUuid(casterUuid) : null; } catch (_) {}
  if (caster) await trackSummon(caster,summon,false);
  Hooks.callAll("ftr.dismissed", casterUuid, summon, reason);
  if (summon.getFlag(SYSTEM_ID,"ephemeral")) await summon.delete();
  return true;
}

export async function dismissAllForCaster(caster) {
  const summons = game.actors.filter(a => a.type === "summon" && a.getFlag(SYSTEM_ID,"summonerUuid") === caster.uuid);
  for (const summon of summons) await dismissSummon(summon);
  await caster.update({"system.summoning.activeActorIds":[]});
}
