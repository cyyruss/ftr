import {SYSTEM_ID} from "../config.mjs";
import {processTurnStart, processTurnEnd} from "./conditions.mjs";

export function mitigationFor(actor, amount, type="") {
  let value = Math.max(0, Number(amount||0));
  const t = String(type||"").toLowerCase();
  const defense = actor.system.defenses ?? {};
  const norm = list => (list ?? []).map(String).map(s=>s.toLowerCase());
  if (t && norm(defense.immunities).includes(t)) value = 0;
  else {
    if (t && norm(defense.resistances).includes(t)) value = Math.floor(value / 2);
    if (t && norm(defense.vulnerabilities).includes(t)) value *= 2;
  }
  value = Math.max(0, value - Number(defense.damageReduction||0));
  return Math.floor(value);
}

export function slayerMultiplier(source, target) {
  const slayer = source?.system?.slayer;
  if (!slayer?.type) return 1;
  const tags = (target?.system?.details?.tags ?? []).map(String).map(s=>s.toLowerCase());
  const explicit = String(slayer.targetTag||"").toLowerCase();
  const type = String(slayer.type||"").toLowerCase();
  const targetTag = explicit || (type.includes("dragon") ? "dragon" : type.includes("god") ? "god" : type.includes("devil") ? "demon" : "");
  if (!targetTag || !tags.includes(targetTag)) return 1;
  return Math.max(1, Number(slayer.damageMultiplier||2));
}

export async function applyTargetedDamage({source, targets=[], amount=0, type="magic", item=null}={}) {
  const results=[];
  for (const target of targets) {
    const actor = target?.actor ?? target;
    if (!actor) continue;
    const mult = slayerMultiplier(source, actor);
    const raw = Math.floor(Number(amount||0) * mult);
    const applied = await actor.applyDamage(raw, type, {source:item?.name ?? source?.name ?? "Damage"});
    results.push({actor, raw, applied, multiplier:mult});
    if (type === "fire" && source?.system?.automation?.autoBurned && source?.system?.magic) {
      const cap = Math.max(1, Number(source.system.abilities?.[source.system.magic.ability]?.mod||0) + Number(source.system.proficiency||0));
      const marks = Math.min(cap, Math.ceil(applied / 2));
      if (marks > 0 && actor.setRankedCondition) await actor.setRankedCondition("burned", marks, {additive:true});
    }
  }
  return results;
}

async function resolveCombatantActor(combat, turn) {
  if (!combat || turn == null || turn < 0) return null;
  const c = combat.turns?.[turn];
  return c?.actor ?? null;
}

export function registerCombatHooks() {
  Hooks.on("combatTurn", async (combat, updateData, updateOptions) => {
    if (!game.user.isGM || !game.settings.get(SYSTEM_ID,"automateTurnConditions") || Number(updateOptions?.direction||0) <= 0) return;
    const currentTurn = Number(combat.turn ?? -1);
    const ending = await resolveCombatantActor(combat, currentTurn);
    if (ending) await processTurnEnd(ending);
    const next = await resolveCombatantActor(combat, Number(updateData.turn ?? -1));
    if (next) {
      await processTurnStart(next);
      await processSummonUpkeep(next);
    }
  });
}

async function processSummonUpkeep(caster) {
  const summons = game.actors.filter(a => a.type === "summon" && a.getFlag(SYSTEM_ID,"summonerUuid") === caster.uuid);
  for (const summon of summons) {
    const upkeep = Number(summon.getFlag(SYSTEM_ID,"maintainCost")||0);
    if (!upkeep) continue;
    if (Number(caster.system.resources.mana.value||0) < upkeep) {
      await game.fairyTailRewired?.summoning?.dismiss?.(summon,{reason:"Not enough Mana for summon upkeep."});
      continue;
    }
    await caster.spendResource("mana",upkeep,{reason:`Maintain ${summon.name}`});
  }
}
