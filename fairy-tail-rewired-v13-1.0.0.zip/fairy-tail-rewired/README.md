# Fairy Tail: Rewired — Foundry VTT v13 System

**Version:** 1.0.0  
**Foundry:** v13  
**System ID:** `fairy-tail-rewired`

A standalone Foundry VTT system built from the user-supplied *Fairy Tail: Rewired 1.0* sourcebook, with an optional lore-expansion layer translated into the same tabletop framework.

## Install / upgrade

1. Back up your world.
2. Shut down Foundry.
3. Remove the old `Data/systems/fairy-tail-rewired/` folder (do not delete your world).
4. Extract this package so the manifest is exactly `Data/systems/fairy-tail-rewired/system.json`.
5. Restart Foundry and open the world as a GM once so schema migrations can run.

The system keeps the same ID as the earlier working build, so existing worlds remain assigned to the same system. Migration data is versioned through the hidden `schemaVersion` world setting.

## Core features

- Custom Fairy Tail-inspired character, NPC/summon, and item sheets.
- Seven Rewired classes with corrected sourcebook hit dice, saving-throw proficiencies, class emblems, and class-specific Mana formulas.
- Rewired ability checks, saves, skills, AC, HP, Mana, Curse Power, Demon Points, movement, resistances, immunities, vulnerabilities, damage reduction, and rests.
- Searchable sourcebook compendia for classes, races, backgrounds, rules, magic, **115 layout-verified spells/techniques**, and source reference material.
- Structured five-milestone magic-path progression. The original Rewired schools preserve their sourcebook option levels (1, 3, 5/6, 10/11, and 18/20 as applicable); lore-expansion schools use the same five-stage structure at 1/3/6/11/18. Choices create real embedded Feature Items and may apply standard Active Effects.
- Character Builder: race/origin → class → magic → background → abilities/skills, with non-destructive updates and advancement history.
- Party Tracker: live HP/MP/Curse, conditions, summons, magic-path alerts, rests, and sheet/builder shortcuts.
- Celestial Spirit Magic: Gate Keys, linked summon Actors, active-Gate limits, summon costs/upkeep, dismissal, scaling, contracts, and Star Dress-compatible transformation data.
- Slayer data/automation for Dragon, God, and Devil Slayer targeting, elemental metadata, Devour, generation tracking, and form state.
- Transformations/Take Over/Requip-friendly Item types using standard Active Effects and equipment Items.
- Ranked Rewired conditions including Burned, Winded, Slowed, Silenced, and Celestia; combat-turn processing can be disabled in settings.
- Boss fields/phases and legendary-style action resources for encounter content.
- Lore equipment/loot compendium with 131 series-referenced entries. Prices and tabletop mechanics are Rewired campaign conversions, not canonical prices/statistics.
- Optional lore races/origins and 52 lore-expansion magic schools, tagged separately from original Rewired content.
- Public API and staged hooks for add-on modules.

## Compatibility philosophy

The system does not replace `Actor.prototype` or `Item.prototype`. It supplies Foundry document classes through `CONFIG`, uses System Data Models, standard Actor/Item documents, standard Active Effects, core targeting, ChatMessages, and public hooks. Automatic damage is **off by default**, so external workflow/damage modules can intercept an action without fighting a second automatic damage pass.

No third-party module can be guaranteed compatible without live testing against that specific module/version. The supported integration surface is documented in `API.md`.

## Lore-expansion boundary

Content marked `lore` is not part of the original Rewired PDF. It is an original tabletop adaptation of setting concepts, balanced to use Rewired resources and the same 1/3/6/11/18 magic-choice cadence. The original PDF remains authoritative where its text and automation disagree.

## Art

The seven class emblems are original vector emblems created for this package. No anime/manga screenshots, copyrighted item art, or unlicensed fan art are bundled. The separate bestiary add-on records lore/image-reference URLs so a GM can attach art they are legally permitted to store in Forge's Assets Library.

## Important scope note

Foundry can automate deterministic rules—rolls, resources, damage, conditions, summons, choices, effects, and bookkeeping. Some Rewired features are intentionally left as readable feature text when the source rule requires GM interpretation, free-form spell alterations, narrative adjudication, or ambiguous wording. Those entries are not silently replaced with invented rules.

## Add-on

Install **Fairy Tail: Rewired — Bestiary** in `Data/modules/fairy-tail-rewired-bestiary/` and enable it in the world. It adds a searchable one-click import browser with 164 encounter profiles.
