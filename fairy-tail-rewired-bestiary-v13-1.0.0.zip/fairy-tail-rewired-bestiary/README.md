# Fairy Tail: Rewired — Bestiary 1.0.0

Requires the **Fairy Tail: Rewired** system 1.0.0+ and Foundry VTT v13.

This add-on contains 164 importable encounter profiles across Dragons, Etherious, Demon/Curse encounters, Celestial Spirits, Eclipse Celestial Spirits, magical creatures, God Seeds, and Grand Magic Games/Pandemonium monsters. Enable the module in a Rewired world and use the **Rewired Bestiary** button in the Actor Directory, or run `game.fairyTailRewiredBestiary.open()`.

## Art and copyright

No third-party Fairy Tail art is bundled. Every entry stores a lore/art source URL and the browser exposes it through the image button. This lets you locate the referenced appearance and then use an image you are legally permitted to store in your Foundry/Forge assets. The bundled placeholder is a Foundry core icon. The module does not hotlink or redistribute anime, manga, wiki, or fan art.

## Mechanics

Stat blocks are original Fairy Tail: Rewired tabletop conversions, not official Fairy Tail RPG statistics. Bosses use the core system's boss-phase and legendary-action fields; Etherious/Demon encounters use Curse Power; Celestial entries use Magic Power; all imported actions use standard Rewired Item documents and the same workflow/hooks as player actions.
