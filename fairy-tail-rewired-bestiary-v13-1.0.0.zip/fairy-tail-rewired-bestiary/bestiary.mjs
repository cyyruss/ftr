const MODULE_ID="fairy-tail-rewired-bestiary";
const SYSTEM_ID="fairy-tail-rewired";
const {ApplicationV2,HandlebarsApplicationMixin}=foundry.applications.api;
let cache=null;

async function loadCreatures(){
  if (cache) return cache;
  const res=await fetch(`modules/${MODULE_ID}/data/creatures.json`);
  if (!res.ok) throw new Error(`Unable to load bestiary data (${res.status}).`);
  cache=await res.json();
  return cache;
}
function flagOf(c){return c.flags?.[MODULE_ID] ?? {};}
function categoryList(rows){return [...new Set(rows.map(c=>flagOf(c).category).filter(Boolean))].sort((a,b)=>a.localeCompare(b));}

class BestiaryBrowser extends HandlebarsApplicationMixin(ApplicationV2){
  static DEFAULT_OPTIONS={id:"ftr-bestiary-browser",tag:"div",classes:["ftr-bestiary-browser"],window:{title:"Fairy Tail: Rewired — Bestiary",icon:"fa-solid fa-dragon",resizable:true},position:{width:980,height:760},actions:{import:BestiaryBrowser._import,source:BestiaryBrowser._source,art:BestiaryBrowser._art,clear:BestiaryBrowser._clear,refresh:BestiaryBrowser._refresh}};
  static PARTS={main:{template:`modules/${MODULE_ID}/templates/browser.hbs`,scrollable:[".ftr-bestiary-results"]}};
  constructor(options={}){super(options);this.query="";this.category="all";this.bossOnly=false;}
  async _prepareContext(){
    const all=await loadCreatures();
    const q=this.query.trim().toLowerCase();
    const creatures=all.filter(c=>{
      const f=flagOf(c),tags=c.system?.details?.tags??[];
      if(this.category!=="all"&&f.category!==this.category)return false;
      if(this.bossOnly&&!c.system?.boss?.enabled)return false;
      if(!q)return true;
      return [c.name,f.category,c.system?.magic?.primary,...tags].join(" ").toLowerCase().includes(q);
    }).map(c=>({id:c._id,name:c.name,img:c.img,category:flagOf(c).category,level:c.system?.level,hp:c.system?.resources?.hp?.max,ac:c.system?.attributes?.ac?.override||c.system?.attributes?.ac?.value,boss:Boolean(c.system?.boss?.enabled),sourceUrl:flagOf(c).sourceUrl,artSourceUrl:flagOf(c).artSourceUrl,tags:(c.system?.details?.tags??[]).slice(0,4)}));
    return {creatures,categories:categoryList(all),query:this.query,selectedCategory:this.category,bossOnly:this.bossOnly,total:all.length,shown:creatures.length};
  }
  _onRender(context,options){
    super._onRender(context,options);
    const root=this.element;
    const search=root.querySelector('[data-filter="search"]');
    const category=root.querySelector('[data-filter="category"]');
    const boss=root.querySelector('[data-filter="boss"]');
    search?.addEventListener("input",ev=>{this.query=ev.currentTarget.value;clearTimeout(this._filterTimer);this._filterTimer=setTimeout(()=>this.render({force:true}),180);});
    category?.addEventListener("change",ev=>{this.category=ev.currentTarget.value;this.render({force:true});});
    boss?.addEventListener("change",ev=>{this.bossOnly=ev.currentTarget.checked;this.render({force:true});});
  }
  async creature(id){return (await loadCreatures()).find(c=>c._id===id);}
  static async _import(event,target){
    event.preventDefault();
    if(!game.user.isGM)return ui.notifications.warn("Only a GM can import bestiary Actors.");
    const creature=await this.creature(target.dataset.id); if(!creature)return;
    const actor=await game.fairyTailRewired.content.importActor(creature,{renderSheet:false});
    ui.notifications.info(`${actor.name} imported to the Actors directory.`); actor.sheet?.render(true);
  }
  static async _source(event,target){event.preventDefault();const c=await this.creature(target.dataset.id);const url=flagOf(c).sourceUrl;if(url)window.open(url,"_blank","noopener");}
  static async _art(event,target){event.preventDefault();const c=await this.creature(target.dataset.id);const url=flagOf(c).artSourceUrl;if(url)window.open(url,"_blank","noopener");}
  static _clear(event,target){event.preventDefault();this.query="";this.category="all";this.bossOnly=false;this.render({force:true});}
  static async _refresh(event,target){event.preventDefault();cache=null;await loadCreatures();this.render({force:true});}
}

export function openBestiary(){const app=new BestiaryBrowser();app.render({force:true});return app;}

function addActorDirectoryButton(app,html){
  try{
    const root=html instanceof HTMLElement?html:(html?.[0]??app?.element);
    if(!root||root.querySelector('[data-ftr-bestiary-button]'))return;
    const actions=root.querySelector('.directory-header .header-actions')||root.querySelector('.directory-header');
    if(!actions)return;
    const btn=document.createElement('button');btn.type='button';btn.dataset.ftrBestiaryButton='1';btn.innerHTML='<i class="fas fa-dragon"></i> Rewired Bestiary';btn.addEventListener('click',()=>openBestiary());actions.append(btn);
  }catch(err){console.debug(`${MODULE_ID} | Actor directory button skipped`,err);}
}

Hooks.once("ready",async()=>{
  if(game.system.id!==SYSTEM_ID)return ui.notifications.warn("Fairy Tail: Rewired — Bestiary requires the Fairy Tail: Rewired system.");
  await loadCreatures();
  const api={version:"1.0.0",open:openBestiary,getAll:()=>loadCreatures(),find:async id=>(await loadCreatures()).find(c=>c._id===id)};
  game.fairyTailRewiredBestiary=api;
  game.fairyTailRewired?.content?.registerProvider?.(MODULE_ID,{label:"Fairy Tail: Rewired Bestiary",version:api.version,getActors:loadCreatures,openBrowser:openBestiary});
  Hooks.callAll("ftr.bestiaryReady",api);
});
Hooks.on("renderActorDirectory",addActorDirectoryButton);
