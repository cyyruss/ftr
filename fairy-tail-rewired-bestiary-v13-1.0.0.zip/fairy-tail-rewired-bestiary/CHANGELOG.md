# Changelog

## 1.0.0

- Initial v13 release for Fairy Tail: Rewired 1.0.0+.
- 164 searchable/importable encounter profiles.
- Magical creatures, Dragons, Etherious/Demons, Celestial/Eclipse Spirits, God Seeds, and representative Pandemonium tiers.
- Rewired-native NPC actions, resources, defenses, boss phases, Curse/Mana usage, and creature tags.
- One-click import browser and public `game.fairyTailRewiredBestiary` API.
- Per-entry lore and art-reference URLs; no third-party image files redistributed.
