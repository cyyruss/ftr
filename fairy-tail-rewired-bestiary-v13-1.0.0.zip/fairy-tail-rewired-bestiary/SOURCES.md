# Bestiary research / art-reference sources

The encounter statistics in this module are original Rewired-compatible tabletop conversions. The URLs below were used to identify setting creatures and to give GMs a place to inspect canonical/reference appearances. No third-party image files are bundled.

Primary catalog/reference pages:

- Magical creatures: https://fairytail.fandom.com/wiki/Category:Magical_Creatures
- Dragons: https://fairytail.fandom.com/wiki/Category:Dragons
- Etherious: https://fairytail.fandom.com/wiki/Category:Etherious
- Demons: https://fairytail.fandom.com/wiki/Category:Demons
- Celestial Spirits: https://fairytail.fandom.com/wiki/Category:Celestial_Spirits
- Eclipse Celestial Spirits: https://fairytail.fandom.com/wiki/Category:Eclipse_Celestial_Spirits
- God Seeds: https://fairytail.fandom.com/wiki/Category:God_Seeds
- Grand Magic Games Monsters / Pandemonium: https://fairytail.fandom.com/wiki/Grand_Magic_Games_Monsters
- Wiki image-gallery index: https://fairytail.fandom.com/wiki/Fairy_Tail_Wiki:Image_Gallery

Each creature record also stores its own `sourceUrl` and `artSourceUrl` under `flags.fairy-tail-rewired-bestiary`.

## Art use

Reference pages may contain copyrighted anime/manga/game images or fan-created work. A visible image on a wiki or art site is not automatically permission to redistribute the underlying file. This module therefore ships only Foundry core placeholder icons. Use the Art Reference button to locate an appearance, then upload only artwork you have the right to store/use to your Forge Assets Library and set the Actor/token image normally in Foundry.
